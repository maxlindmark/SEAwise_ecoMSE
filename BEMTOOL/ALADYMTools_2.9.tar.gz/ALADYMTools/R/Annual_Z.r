# ALADYM  Age length based dynamic model
# Authors: G. Lembo, I. Bitetto, M.T. Facchini, M.T. Spedicato 2013
# COISPA Tecnologia & Ricerca, Via dei Trulli 18/20 - (Bari), Italy 
# In case of use of the model, the Authors should be cited.
# If you have any comments or suggestions please contact the following e-mail address: facchini@coispa.it
# ALADYM is believed to be reliable. However, we disclaim any implied warranty or representation about its accuracy, 
# completeness or appropriateness for any particular purpose.

.Annual_Z <- function (End){
#End=forecast-1


if (showCompTime)  {
Annual_Z_ptm <- proc.time()  
}

n_ages_mal <- INP$MGrowth_tend
n_ages_fem <- INP$FGrowth_tend

first_age <- 0
    n_ages_mal <- n_ages_mal - trunc(INP$tr/12)
        n_ages_fem <- n_ages_fem - trunc(INP$tr/12)
    first_age <- trunc(INP$tr/12)

BAS$indices_MAge <-  data.frame(matrix(cbind(BAS$MAge, trunc(BAS$MAge)), ncol=2))
colnames(BAS$indices_MAge) <- c("age", "age_class")
indices_M_first_age <- which(BAS$indices_MAge$age_class == first_age)

BAS$indices_FAge <-  data.frame(matrix(cbind(BAS$FAge, trunc(BAS$FAge)), ncol=2))
colnames(BAS$indices_FAge) <- c("age", "age_class")
indices_F_first_age <- which(BAS$indices_FAge$age_class == first_age)


ind= which(INP$Fertility_Rate_inp!=0)[1] #- 1 - INP$Fertility_Delay                   # mese in cui entrano le prime reclute



loca <-c(1:(End/INP$Time_slice))
# creazione degli oggetti in cui andranno le mortalit� 
SRO$Annual_Z_males = data.frame(matrix(ncol=End/INP$Time_slice,nrow=n_ages_mal), row.names= c(first_age:(n_ages_mal+first_age-1)))
SRO$Annual_Z_females = data.frame(matrix(ncol=End/INP$Time_slice, nrow=n_ages_fem), row.names= c(first_age:(n_ages_fem+first_age-1)))
SRO$Annual_Z= data.frame(matrix(ncol=End/INP$Time_slice, nrow=max(n_ages_mal, n_ages_fem)), row.names= c(first_age:(max(n_ages_mal, n_ages_fem)+first_age-1)))
SRO$Annual_Z_by_year = data.frame(matrix(nrow=End/INP$Time_slice,ncol=1))
SRO$Annual_Z_by_year_ls = data.frame(matrix(nrow=End/INP$Time_slice,ncol=1))

#if (tr>ind) {

for (i in loca) {

MFPopulation_temp = SRO$MFPopulation[(2+(i-1)*12):(1+i*12),]    # selezione anno i
FFPopulation_temp = SRO$FFPopulation[(2+(i-1)*12):(1+i*12),]

# ETA' 0
j1M = 1                  # prima classe di et�
i1M = ind         # prima riga non nulla
i2M = ifelse(ind>=(modulo(INP$tr,INP$Time_slice)-1),12,(INP$Time_slice - modulo(INP$tr,INP$Time_slice)+1))                                         # avanzamento della colonna (et�)
j2M =  ifelse(ind>=(modulo(INP$tr,INP$Time_slice)-1),j1M + 12-ind,(INP$Time_slice - modulo(INP$tr,INP$Time_slice)+1))                                        # avanzamento della riga (tempo)

j1F = 1                  # prima classe di et�
i1F = ind         # prima riga non nulla
i2F = ifelse(ind>=(modulo(INP$tr,INP$Time_slice)-1),12,(INP$Time_slice - modulo(INP$tr,INP$Time_slice)+1))                                          # avanzamento della colonna (et�)
j2F = ifelse(ind>=(modulo(INP$tr,INP$Time_slice)-1),j1F + 12-ind,(INP$Time_slice - modulo(INP$tr,INP$Time_slice)+1))# j1F + 12-ind                                        # avanzamento della riga (tempo)

x = ifelse(ind>=(modulo(INP$tr,INP$Time_slice)), (12-ind)  ,12-(modulo(INP$tr,INP$Time_slice)   ))      #   +1      -1 
  
 SRO$Annual_Z_males[1,i] =  log(MFPopulation_temp[i1M,j1M] /MFPopulation_temp[i2M,j2M]) / x *12      
 SRO$Annual_Z_females[1,i] =  log(FFPopulation_temp[i1F,j1F] /FFPopulation_temp[i2F,j2F]) / x *12             
 SRO$Annual_Z[1,i] =  mean(na.omit(c(SRO$Annual_Z_males[1,i],SRO$Annual_Z_females[1,i])))

# ETA' SUCCESSIVE                                                                                                                                                               
    for (a in  seq(trunc(INP$tr/12)+1,(max(INP$MGrowth_tend,INP$FGrowth_tend)-1),1)){
    j1M = which(round(BAS$MAge,8)==(a)) +1                  # individuazione colonna di et� a
    
    if (a>(INP$MGrowth_tend-1) ){
    i1M = NA     } else {
    i1M = which(MFPopulation_temp[,j1M]!=0)[1]
    }          # individuazione prima riga in cui trovo animali
    
    i2M = 12                                         # avanzamento della colonna (et�)
    j2M = j1M + 12-i1M                                        # avanzamento della riga (tempo)
    
    j1F = which(round(BAS$FAge,8)==(a))+1                   # individuazione colonna di et� a
    if (a>(INP$FGrowth_tend-1) ){
    i1F = NA     } else {
    i1F = which(FFPopulation_temp[,j1F]!=0)[1]
    }  # individuazione prima riga in cui trovo animali         
    
    i2F = 12                                         # avanzamento della colonna (et�)
    j2F = j1F + 12-i1F                                        # avanzamento della riga (tempo)
    
     if (a<=(INP$MGrowth_tend-1)) {
        SRO$Annual_Z_males[a-trunc(INP$tr/12)+1,i] = log(MFPopulation_temp[i1M,j1M] /MFPopulation_temp[i2M,j2M])  / (12-i1M)   *12 
     }
#    SRO$Annual_Z_males[a-trunc(INP$tr/12)+1,i] = ifelse(a<=(INP$MGrowth_tend-1), log(MFPopulation_temp[i1M,j1M] /MFPopulation_temp[i2M,j2M])  / (12-i1M)   *12  ,NA) 

if (a<=(INP$FGrowth_tend-1)) {
    SRO$Annual_Z_females[a-trunc(INP$tr/12)+1,i]  =  log(FFPopulation_temp[i1F,j1F] /FFPopulation_temp[i2F,j2F])  / (12-i1F)   *12
}
   # SRO$Annual_Z_females[a-trunc(INP$tr/12)+1,i]  = ifelse(a<=(INP$FGrowth_tend-1), log(FFPopulation_temp[i1F,j1F] /FFPopulation_temp[i2F,j2F])  / (12-i1F)   *12  , NA) 
    
    SRO$Annual_Z[a-trunc(INP$tr/12)+1,i]  = mean(na.omit(c(SRO$Annual_Z_males[a-trunc(INP$tr/12)+1,i],SRO$Annual_Z_females[a-trunc(INP$tr/12)+1,i])))
    
    }

}
                                                                                                        

rownames(SRO$Annual_Z_females)= c(first_age:(n_ages_fem+first_age-1))
rownames(SRO$Annual_Z_males)= c(first_age:(n_ages_mal+first_age-1))
for (i in 1:ncol(SRO$Annual_Z)){
  SRO$Annual_Z_by_year_ls[i,1]= mean(SRO$Annual_Z[,i],na.rm=T)
  SRO$Annual_Z_by_year[i,1]=(mean(SRO$Annual_Z_males[which(rownames(SRO$Annual_Z_males) ==  INP$min_ageM):which(rownames(SRO$Annual_Z_males) ==  INP$max_ageM ),i],na.rm=T)+mean(SRO$Annual_Z_females[which(rownames(SRO$Annual_Z_females) == INP$min_ageF):which(rownames(SRO$Annual_Z_females) ==  INP$max_ageF ),i],na.rm=T)) / 2
}
#
#

 if (showCompTime)  {
 proc_ <- proc.time()
print(paste("Annual_Z [time]::::::::::::::::::::::::::::::::", round(as.numeric(proc_[3]-Annual_Z_ptm[3]),2), "sec" ), quote=F )   
rm(Annual_Z_ptm)
}

}

#SRO$Annual_Z  