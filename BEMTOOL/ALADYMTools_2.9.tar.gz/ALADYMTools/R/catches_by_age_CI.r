# BEMTOOL - Bio-Economic Model TOOLs - version 2.0
# Authors: G. Lembo, I. Bitetto, M.T. Facchini, M.T. Spedicato 2014
# COISPA Tecnologia & Ricerca, Via dei Trulli 18/20 - (Bari), Italy 
# In case of use of the model, the Authors should be cited.
# If you have any comments or suggestions please contact the following e-mail address: facchini@coispa.it
# BEMTOOL is believed to be reliable. However, we disclaim any implied warranty or representation about its accuracy, 
# completeness or appropriateness for any particular purpose.




.catches_by_age_CI <- function(loca_End) {
#---- CATCH IN NUMBERS TABLES

# loca_End = this_End
if (showCompTime)  {
catches_by_age_CI_ptm <- proc.time()  
}


if (IN_BEMTOOL) {
associated_fleetsegment <<- as.vector(cfg[rownames(cfg)==paste("casestudy.S", ALADYM_spe, ".associatedFleetsegment", sep=""), ])   
associated_fleetsegment <<- associated_fleetsegment[!is.na(associated_fleetsegment) & associated_fleetsegment!="" & associated_fleetsegment!="-"]

FLEETSEGMENTS_names <<- associated_fleetsegment
#print(FLEETSEGMENTS_names)
}


loca <-c(1:(loca_End/INP$Time_slice))

if (exists("num_iter_RPs")) {
    loca_y <- loca
} else {

if (INP$Year_simulation == length(years) ) {
    loca_y <- years
}   else {
loca_y <- c(years, years_forecast)
loca_y <- loca_y[loca]
}

}



NcolM = INP$MGrowth_tend- trunc(INP$tr/12)

catch_gearsM <- vector(mode="list", length = length(FLEETSEGMENTS_names))
#print("dentro catch by age:")
#print(SRO$MFCatch_gears[,1,1])

for (n in 1:length(FLEETSEGMENTS_names)) {
   
catch2 <- apply(SRO$MFCatch_gears[,,n], MARGIN=2, FUN="sumWequals",  para_vectLength = (loca_End + 1) , para_pointsMean = INP$Time_slice )
catch1 =  data.frame(matrix(rowSums(catch2[,1:(INP$Time_slice - modulo(INP$tr,INP$Time_slice))], na.rm=T) , ncol=1) )

#print(paste("numero gear:", n))
#print(catch1[,1])

catch <- t(apply(catch2[,(INP$Time_slice - modulo(INP$tr,INP$Time_slice)):ncol(catch2)], MARGIN=1, FUN="sumWequals",  para_vectLength = (ncol(catch2)-(INP$Time_slice - modulo(INP$tr,INP$Time_slice)) + 1 ), para_pointsMean = INP$Time_slice ))

catchM = cbind(catch1,catch)
 
    colnames(catchM) <- c(paste(seq(trunc(INP$tr/INP$Time_slice),(GLO$MC_number+INP$tr-1)/INP$Time_slice -1 ,1),"-",seq(trunc(INP$tr/12+1,0),(GLO$MC_number+INP$tr)/INP$Time_slice ,1)))
  catch_gearsM[[n]] <- catchM

}





# FEMMINE
# raggruppamento mesi

NcolF = INP$FGrowth_tend- trunc(INP$tr/12)
catch_gearsF <- vector(mode="list", length = length(FLEETSEGMENTS_names))

for (n in 1:length(FLEETSEGMENTS_names)) {
    
	catch2 <- apply(SRO$FFCatch_gears[,,n], MARGIN=2, FUN="sumWequals",  para_vectLength = (loca_End + 1) , para_pointsMean = INP$Time_slice )  

# raggruppamento et? primo anno reclutato
catch1 =  data.frame(matrix(rowSums(catch2[,1:(INP$Time_slice - modulo(INP$tr,INP$Time_slice))], na.rm=T) , ncol=1) )

# anni di et? successivi

catch <- t(apply(catch2[,(INP$Time_slice - modulo(INP$tr,INP$Time_slice)):ncol(catch2)], MARGIN=1, FUN="sumWequals",  para_vectLength = (ncol(catch2)-(INP$Time_slice - modulo(INP$tr,INP$Time_slice)) + 1 ), para_pointsMean = INP$Time_slice ))

catchF = cbind(catch1,catch)

colnames(catchF) <- c(paste(seq(trunc(INP$tr/INP$Time_slice),(GLO$FC_number+INP$tr-1)/INP$Time_slice -1 ,1),"-",seq(trunc(INP$tr/12+1,0),(GLO$FC_number+INP$tr)/INP$Time_slice ,1)))
  catch_gearsF[[n]] <- catchF
 
}


#------SALVATAGGIO TABELLE CATCH-------
max_age = max(INP$MGrowth_tend,INP$FGrowth_tend) #max(max_ageM,max_ageF)

catch_fin = data.frame(catch_gearsM[[1]])
if (ncol(catch_fin)<(max_age-trunc(INP$tr/INP$Time_slice))){
  for (i in 1:(max_age-ncol(catch_fin)-trunc(INP$tr/INP$Time_slice))) {
  catch_fin =cbind(catch_fin,0)
  }
}

catch_fin$sex= rep("M" ,(loca_End / INP$Time_slice))
catch_fin$gear= rep(FLEETSEGMENTS_names[1] ,(loca_End / INP$Time_slice))

if (length(FLEETSEGMENTS_names)!=1) {
  for (n in 2:length(FLEETSEGMENTS_names)){
    catch_fin2 = data.frame(catch_gearsM[[n]])

  if (ncol(catch_fin2)<(max_age-trunc(INP$tr/INP$Time_slice))){
    for (i in 1:(max_age-ncol(catch_fin2)-trunc(INP$tr/INP$Time_slice))){
    catch_fin2 =cbind(catch_fin2,0)
    }
  }
  catch_fin2$sex= rep("M" ,(loca_End / INP$Time_slice))
  catch_fin2$gear= rep(FLEETSEGMENTS_names[n] ,(loca_End / INP$Time_slice))
  catch_fin=rbind(catch_fin,catch_fin2)
  }

}
# females

 catch_finF = data.frame(catch_gearsF[[1]])
if (ncol(catch_finF)<(max_age-trunc(INP$tr/INP$Time_slice))){
 for (i in 1:(max_age-ncol(catch_finF)-trunc(INP$tr/INP$Time_slice))){
  catch_finF =cbind(catch_finF,0)
  }
}

catch_finF$sex= rep("F" ,(loca_End / INP$Time_slice))
catch_finF$gear= rep(FLEETSEGMENTS_names[1] ,(loca_End / INP$Time_slice))

if (length(FLEETSEGMENTS_names)!=1) {
  for (n in 2:length(FLEETSEGMENTS_names)){
    catch_fin2F = data.frame(catch_gearsF[[n]])
  if (ncol(catch_fin2F)<(max_age-trunc(INP$tr/INP$Time_slice))){
    for (i in 1:(max_age-ncol(catch_fin2F)-trunc(INP$tr/INP$Time_slice))){
    catch_fin2F =cbind(catch_fin2F,0)
    }
  }
  catch_fin2F$sex= rep("F" ,(loca_End / INP$Time_slice))
  catch_fin2F$gear= rep(FLEETSEGMENTS_names[n] ,(loca_End / INP$Time_slice))
  catch_finF=rbind(catch_finF,catch_fin2F)
  }

}

#
catch_fin = cbind(loca_y,catch_fin)
catch_finF = cbind(loca_y,catch_finF)
colnames(catch_fin) = c("Year/Age",c(seq(trunc(INP$tr/INP$Time_slice),(max_age-1),1)),"sex","Gear")
colnames(catch_finF)= c("Year/Age",c(seq(trunc(INP$tr/INP$Time_slice),(max_age-1),1)),"sex","Gear")

catch_fin=rbind(catch_finF,catch_fin)

catch_fin_to_return <- catch_fin

 if (!INTEGRATED_APPROACH) {
colnames(catch_fin_to_return)  <- Catches_by_age_ALLruns_head[-length(Catches_by_age_ALLruns_head)]
  } else {
 	 colnames(catch_fin_to_return)  <- colnames(INP$Catches_by_age_ALLruns)[-length(colnames(INP$Catches_by_age_ALLruns))] 
  }
  
catch_fin <- data.frame(cbind(catch_fin, rep(current_runCI, nrow(catch_fin)))  )

 if (!INTEGRATED_APPROACH) {
	 colnames(catch_fin)  <- Catches_by_age_ALLruns_head
  } else {
 	 colnames(catch_fin)  <- colnames(INP$Catches_by_age_ALLruns)
  }
  
  


if (!INTEGRATED_APPROACH) {
Catches_by_age_ALLruns <<- data.frame(rbind(Catches_by_age_ALLruns, catch_fin))
} else {


if (!exists("TAC_LEVEL_LOOP") ) {
if (exists("TAC_ROUND") & TAC_ROUND == 2) {
     INP$Catches_by_age_ALLruns <- data.frame(rbind(INP$Catches_by_age_ALLruns[ - which(INP$Catches_by_age_ALLruns$run == current_runCI & INP$Catches_by_age_ALLruns$Year== years_forecast[current_year]) , ], catch_fin[catch_fin$Year == years_forecast[current_year],]))  
} else {
  if (current_year ==1) {
     INP$Catches_by_age_ALLruns <- data.frame(rbind(INP$Catches_by_age_ALLruns, catch_fin)) 
  } else {
    INP$Catches_by_age_ALLruns <- data.frame(rbind(INP$Catches_by_age_ALLruns, catch_fin[catch_fin$Year == years_forecast[current_year],]))
  }
}
}


}





#----------------------------------------------

##---- LANDINGS IN NUMBERS TABLES
land_gearsM <- vector(mode="list", length = length(FLEETSEGMENTS_names))


for (n in 1:length(FLEETSEGMENTS_names)){

land2 <- apply(SRO$MFLanding_gears[,,n], MARGIN=2, FUN="sumWequals",  para_vectLength = (loca_End + 1) , para_pointsMean = INP$Time_slice )

# raggruppamento et? primo anno reclutato
 land1 =  data.frame(matrix(rowSums(land2[,1:(INP$Time_slice - modulo(INP$tr,INP$Time_slice))], na.rm=T) , ncol=1) )

# anni di et? successivi
land <- t(apply(land2[,(INP$Time_slice - modulo(INP$tr,INP$Time_slice)):ncol(land2)], MARGIN=1, FUN="sumWequals",  para_vectLength = (ncol(land2)-(INP$Time_slice - modulo(INP$tr,INP$Time_slice)) + 1 ), para_pointsMean = INP$Time_slice ))
landM = cbind(land1,land)

    colnames(landM) <- c(paste(seq(trunc(INP$tr/INP$Time_slice),(GLO$MC_number+INP$tr-1)/INP$Time_slice -1 ,1),"-",seq(trunc(INP$tr/12+1,0),(GLO$MC_number+INP$tr)/INP$Time_slice ,1)))
  land_gearsM[[n]] <- landM

    
}

# FEMMINE
# raggruppamento mesi
NcolF = INP$FGrowth_tend- trunc(INP$tr/12)
land_gearsF <- vector(mode="list", length = length(FLEETSEGMENTS_names))

for (n in 1:length(FLEETSEGMENTS_names)){
      land2 <- apply(SRO$FFLanding_gears[,,n], MARGIN=2, FUN="sumWequals",  para_vectLength = (loca_End + 1) , para_pointsMean = INP$Time_slice )   

# raggruppamento et? primo anno reclutato
land1 =  data.frame(matrix(rowSums(land2[,1:(INP$Time_slice - modulo(INP$tr,INP$Time_slice))], na.rm=T) , ncol=1) )
# anni di et? successivi
 land <- t(apply(land2[,(INP$Time_slice - modulo(INP$tr,INP$Time_slice)):ncol(land2)], MARGIN=1, FUN="sumWequals",  para_vectLength = (ncol(land2)-(INP$Time_slice - modulo(INP$tr,INP$Time_slice)) + 1 ), para_pointsMean = INP$Time_slice ))
landF = cbind(land1,land)

    colnames(landF) <- c(paste(seq(trunc(INP$tr/INP$Time_slice),(GLO$FC_number+INP$tr-1)/INP$Time_slice -1 ,1),"-",seq(trunc(INP$tr/12+1,0),(GLO$FC_number+INP$tr)/INP$Time_slice ,1)))
  land_gearsF[[n]] <- landF
   
}

#------SALVATAGGIO TABELLE CATCH-------
max_age = max(INP$MGrowth_tend,INP$FGrowth_tend) #max(max_ageM,max_ageF)

land_fin = data.frame(land_gearsM[[1]])
if (ncol(land_fin)<(max_age-trunc(INP$tr/INP$Time_slice))){
  for (i in 1:(max_age-ncol(land_fin)-trunc(INP$tr/INP$Time_slice))){
  land_fin =cbind(land_fin,0)
  }
}

land_fin$sex= rep("M" ,(loca_End / INP$Time_slice))
land_fin$gear= rep(FLEETSEGMENTS_names[1] ,(loca_End / INP$Time_slice))

if (length(FLEETSEGMENTS_names)!=1) {
  for (n in 2:length(FLEETSEGMENTS_names)){
  land_fin2 = data.frame(land_gearsM[[n]])
  
  if (ncol(land_fin2)<(max_age-trunc(INP$tr/INP$Time_slice))){
    for (i in 1:(max_age-ncol(land_fin2)-trunc(INP$tr/INP$Time_slice))){
    land_fin2 =cbind(land_fin2,0)
    }
  }
  land_fin2$sex= rep("M" ,(loca_End / INP$Time_slice))
  land_fin2$gear= rep(FLEETSEGMENTS_names[n] ,(loca_End / INP$Time_slice))
  land_fin=rbind(land_fin,land_fin2)
  }

}
# females

land_finF = data.frame(land_gearsF[[1]])
if (ncol(land_finF)<(max_age-trunc(INP$tr/INP$Time_slice))){
  for (i in 1:(max_age-ncol(land_finF)-trunc(INP$tr/INP$Time_slice))){
  land_finF =cbind(land_finF,0)
  }
}

land_finF$sex= rep("F" ,(loca_End / INP$Time_slice))
land_finF$gear= rep(FLEETSEGMENTS_names[1] ,(loca_End / INP$Time_slice))

if (length(FLEETSEGMENTS_names)!=1) {
  for (n in 2:length(FLEETSEGMENTS_names)){
    land_fin2F = data.frame(land_gearsF[[n]])

  if (ncol(land_fin2F)<(max_age-trunc(INP$tr/INP$Time_slice))){
    for (i in 1:(max_age-ncol(land_fin2F)-trunc(INP$tr/INP$Time_slice))){
    land_fin2F =cbind(land_fin2F,0)
    }
  }
  land_fin2F$sex= rep("F" ,(loca_End / INP$Time_slice))
  land_fin2F$gear= rep(FLEETSEGMENTS_names[n] ,(loca_End / INP$Time_slice))
  land_finF=rbind(land_finF,land_fin2F)
  }

}

land_fin = cbind(loca_y,land_fin)
land_finF = cbind(loca_y,land_finF)
colnames(land_fin) = c("Year/Age",c(seq(trunc(INP$tr/INP$Time_slice),(max_age-1),1)),"sex","Gear")
colnames(land_finF)= c("Year/Age",c(seq(trunc(INP$tr/INP$Time_slice),(max_age-1),1)),"sex","Gear")
land_fin=rbind(land_finF,land_fin)


land_fin <- data.frame(cbind(land_fin, rep(current_runCI, nrow(land_fin)))  )

 if (!INTEGRATED_APPROACH) {
	 colnames(land_fin)  <- Landings_by_age_ALLruns_head
  } else {
 	 colnames(land_fin)  <- colnames(INP$Landings_by_age_ALLruns)
  }
  


if (!INTEGRATED_APPROACH) {
Landings_by_age_ALLruns <<- data.frame(rbind(Landings_by_age_ALLruns, land_fin))
} else {


if (!exists("TAC_LEVEL_LOOP") ) {
if (exists("TAC_ROUND") & TAC_ROUND == 2) {
     INP$Landings_by_age_ALLruns <- data.frame(rbind(INP$Landings_by_age_ALLruns[ - which(INP$Landings_by_age_ALLruns$run == current_runCI & INP$Landings_by_age_ALLruns$Year== years_forecast[current_year]) , ], land_fin[land_fin$Year == years_forecast[current_year],]))  
} else {
  if (current_year ==1) {
     INP$Landings_by_age_ALLruns <- data.frame(rbind(INP$Landings_by_age_ALLruns, land_fin)) 
  } else {
    INP$Landings_by_age_ALLruns <- data.frame(rbind(INP$Landings_by_age_ALLruns, land_fin[land_fin$Year == years_forecast[current_year],]))
  }
}
}



}

#DISCARDS AT AGE
dis_gearsM <- vector(mode="list", length = length(FLEETSEGMENTS_names))


for (n in 1:length(FLEETSEGMENTS_names)){
dis2 <- apply(SRO$MFDiscard_gears[,,n], MARGIN=2, FUN="sumWequals",  para_vectLength = (loca_End + 1) , para_pointsMean = INP$Time_slice )
  dis1 =  data.frame(matrix(rowSums(dis2[,1:(INP$Time_slice - modulo(INP$tr,INP$Time_slice))], na.rm=T) , ncol=1) )
# raggruppamento et? primo anno reclutato
dis <- t(apply(dis2[,(INP$Time_slice - modulo(INP$tr,INP$Time_slice)):ncol(dis2)], MARGIN=1, FUN="sumWequals",  para_vectLength = (ncol(dis2)-(INP$Time_slice - modulo(INP$tr,INP$Time_slice)) + 1 ), para_pointsMean = INP$Time_slice ))

disM = cbind(dis1,dis)
   colnames(disM) <- c(paste(seq(trunc(INP$tr/INP$Time_slice),(GLO$MC_number+INP$tr-1)/INP$Time_slice -1 ,1),"-",seq(trunc(INP$tr/12+1,0),(GLO$MC_number+INP$tr)/INP$Time_slice ,1)))
  dis_gearsM[[n]] <- disM
}


# FEMMINE
# raggruppamento mesi

dis_gearsF <- vector(mode="list", length = length(FLEETSEGMENTS_names))

for (n in 1:length(FLEETSEGMENTS_names)){
dis2 <- apply(SRO$FFDiscard_gears[,,n], MARGIN=2, FUN="sumWequals",  para_vectLength = (loca_End + 1) , para_pointsMean = INP$Time_slice )

    
# raggruppamento et? primo anno reclutato
dis1 =  data.frame(matrix(rowSums(dis2[,1:(INP$Time_slice - modulo(INP$tr,INP$Time_slice))], na.rm=T) , ncol=1) )

 dis <- t(apply(dis2[,(INP$Time_slice - modulo(INP$tr,INP$Time_slice)):ncol(dis2)], MARGIN=1, FUN="sumWequals",  para_vectLength = (ncol(dis2)-(INP$Time_slice - modulo(INP$tr,INP$Time_slice)) + 1 ), para_pointsMean = INP$Time_slice ))

# anni di et? successivi
dis = data.frame(matrix(sumWequals(dis2[1,(INP$Time_slice - modulo(INP$tr,INP$Time_slice)):ncol(dis2)], ncol(dis2)-(INP$Time_slice - modulo(INP$tr,INP$Time_slice)) + 1, INP$Time_slice), ncol=NcolF-1 ))  #**
disF = cbind(dis1,dis)

 colnames(disF) <- c(paste(seq(trunc(INP$tr/INP$Time_slice),(GLO$FC_number+INP$tr-1)/INP$Time_slice -1 ,1),"-",seq(trunc(INP$tr/12+1,0),(GLO$FC_number+INP$tr)/INP$Time_slice ,1)))
  dis_gearsF[[n]] <- disF
    
}

#------SALVATAGGIO TABELLE DISCARD-------
max_age = max(INP$MGrowth_tend,INP$FGrowth_tend) #max(max_ageM,max_ageF)
dis_fin = data.frame(dis_gearsM[[1]])

if (ncol(dis_fin)<(max_age-trunc(INP$tr/INP$Time_slice))){

  for (i in 1:(max_age-ncol(dis_fin)-trunc(INP$tr/INP$Time_slice))){
  dis_fin =cbind(dis_fin,0)
  }
}

dis_fin$sex= rep("M" ,(loca_End / INP$Time_slice))
dis_fin$gear= rep(FLEETSEGMENTS_names[1] ,(loca_End / INP$Time_slice))

if (length(FLEETSEGMENTS_names)!=1) {
  for (n in 2:length(FLEETSEGMENTS_names)){
  dis_fin2 = data.frame(dis_gearsM[[n]])

  if (ncol(dis_fin2)<(max_age-trunc(INP$tr/INP$Time_slice))){
    for (i in 1:(max_age-ncol(dis_fin2)-trunc(INP$tr/INP$Time_slice))){
    dis_fin2 =cbind(dis_fin2,0)
    }
  }
  dis_fin2$sex= rep("M" ,(loca_End / INP$Time_slice))
  dis_fin2$gear= rep(FLEETSEGMENTS_names[n] ,(loca_End / INP$Time_slice))
  dis_fin=rbind(dis_fin,dis_fin2)
  }

}
# females

dis_finF = data.frame(dis_gearsF[[1]])
if (ncol(dis_finF)<(max_age-trunc(INP$tr/INP$Time_slice))){

  for (i in 1:(max_age-ncol(dis_finF)-trunc(INP$tr/INP$Time_slice))){
  dis_finF =cbind(dis_finF,0)
  }
}

dis_finF$sex= rep("F" ,(loca_End / INP$Time_slice))
dis_finF$gear= rep(FLEETSEGMENTS_names[1] ,(loca_End / INP$Time_slice))

if (length(FLEETSEGMENTS_names)!=1) {
  for (n in 2:length(FLEETSEGMENTS_names)){
  dis_fin2F = data.frame(dis_gearsF[[n]])

  if (ncol(dis_fin2F)<(max_age-trunc(INP$tr/INP$Time_slice))){
    for (i in 1:(max_age-ncol(dis_fin2F)-trunc(INP$tr/INP$Time_slice))){
    dis_fin2F =cbind(dis_fin2F,0)
    }
  }
  dis_fin2F$sex= rep("F" ,(loca_End / INP$Time_slice))
  dis_fin2F$gear= rep(FLEETSEGMENTS_names[n] ,(loca_End / INP$Time_slice))
  dis_finF=rbind(dis_finF,dis_fin2F)
  }

}

dis_fin = cbind(loca_y,dis_fin)
dis_finF = cbind(loca_y,dis_finF)
colnames(dis_fin) = c("Year/Age",c(seq(trunc(INP$tr/INP$Time_slice),(max_age-1),1)),"sex","Gear")
colnames(dis_finF)= c("Year/Age",c(seq(trunc(INP$tr/INP$Time_slice),(max_age-1),1)),"sex","Gear")
dis_fin=rbind(dis_finF,dis_fin)

 dis_fin <- data.frame(cbind(dis_fin, rep(current_runCI, nrow(dis_fin)))  )
 
  if (!INTEGRATED_APPROACH) {
	 colnames(dis_fin)  <- Discards_by_age_ALLruns_head
  } else {
 	 colnames(dis_fin)  <- colnames(INP$Discards_by_age_ALLruns) 
  }

if (!INTEGRATED_APPROACH) {
Discards_by_age_ALLruns <<- data.frame(rbind(Discards_by_age_ALLruns, dis_fin))
} else {

if (!exists("TAC_LEVEL_LOOP") ) {
if (exists("TAC_ROUND") & TAC_ROUND == 2) {
     INP$Discards_by_age_ALLruns <- data.frame(rbind(INP$Discards_by_age_ALLruns[ - which(INP$Discards_by_age_ALLruns$run == current_runCI & INP$Discards_by_age_ALLruns$Year== years_forecast[current_year]) , ], dis_fin[dis_fin$Year == years_forecast[current_year],]))  
} else {
  if (current_year ==1) {
     INP$Discards_by_age_ALLruns <- data.frame(rbind(INP$Discards_by_age_ALLruns, dis_fin)) 
  } else {
    INP$Discards_by_age_ALLruns <- data.frame(rbind(INP$Discards_by_age_ALLruns, dis_fin[dis_fin$Year == years_forecast[current_year],]))
  }
}
}

}

 if (showCompTime)  {
 proc_ <- proc.time()
print(paste("catches_by_age_CI [time]::::::::::::::::::::::::::::::::", round(as.numeric(proc_[3]-catches_by_age_CI_ptm[3]),2), "sec" ), quote=F )   
rm(catches_by_age_CI_ptm)
}


return(catch_fin_to_return)
}
