# ALADYM  Age length based dynamic model

# Authors: G. Lembo, I. Bitetto, M.T. Facchini, M.T. Spedicato 2014
# COISPA Tecnologia & Ricerca, Via dei Trulli 18/20 - (Bari), Italy 
# In case of use of the model, the Authors should be cited.
# If you have any comments or suggestions please contact the following e-mail address: facchini@coispa.it
# BEMTOOL is believed to be reliable. However, we disclaim any implied warranty or representation about its accuracy, 
# completeness or appropriateness for any particular purpose.

.Annual_F <- function (End){
if (FALSE) {
End = GLO$L_number
}

if (showCompTime)  {
Annual_F_ptm <- proc.time()  
}

if (IN_BEMTOOL) {
associated_fleetsegment <<- as.vector(cfg[rownames(cfg)==paste("casestudy.S", ALADYM_spe, ".associatedFleetsegment", sep=""), ])   
associated_fleetsegment <<- associated_fleetsegment[!is.na(associated_fleetsegment) & associated_fleetsegment!=""]
associated_fleetsegment_indices <<- which(associated_fleetsegment %in% BMT_FLEETSEGMENTS)

FLEETSEGMENTS_names <<- BMT_FLEETSEGMENTS[associated_fleetsegment_indices]
#print(FLEETSEGMENTS_names)
}


loca <-c(1:(End/INP$Time_slice))

if (exists("num_iter_RPs")) {

    loca_y <- loca
} else {

if (INP$Year_simulation == length(years) ) {
    loca_y <- years
}   else {
loca_y <- c(years, years_forecast)
loca_y <- loca_y[loca]
}

}



n_ages_mal <- INP$MGrowth_tend
n_ages_fem <- INP$FGrowth_tend

first_age <- 0

    n_ages_mal <- n_ages_mal - trunc(INP$tr/12)
    n_ages_fem <- n_ages_fem - trunc(INP$tr/12)
    first_age <- trunc(INP$tr/12)

SRO$Annual_F_males_by_gear = array(dim=c((End)/INP$Time_slice, n_ages_mal, length(FLEETSEGMENTS_names)))  
SRO$Annual_F_females_by_gear = array(dim=c((End)/INP$Time_slice, n_ages_fem, length(FLEETSEGMENTS_names)))  

BAS$indices_MAge <-  data.frame(matrix(cbind(BAS$MAge, trunc(round(BAS$MAge,1))), ncol=2))
colnames(BAS$indices_MAge) <- c("age", "age_class")
indices_M_first_age <- which(BAS$indices_MAge$age_class == first_age)

BAS$indices_FAge <-  data.frame(matrix(cbind(BAS$FAge, trunc(round(BAS$FAge,1))), ncol=2))
colnames(BAS$indices_FAge) <- c("age", "age_class")
indices_F_first_age <- which(BAS$indices_FAge$age_class == first_age)




# creazione degli oggetti in cui andranno le mortalit? 
SRO$Annual_F_males = data.frame(matrix(ncol=End/INP$Time_slice,nrow=n_ages_mal), row.names= c(first_age:(n_ages_mal+first_age-1)) )   
SRO$Annual_F_females = data.frame(matrix(ncol=End/INP$Time_slice,nrow=n_ages_fem), row.names=c(first_age:(n_ages_fem+first_age-1)) )
SRO$Annual_F = data.frame(matrix(ncol=End/INP$Time_slice,nrow=max(n_ages_mal, n_ages_fem)), row.names=c(first_age:(max(n_ages_mal, n_ages_fem)+first_age-1)) )
#SRO$Annual_F_by_gear = data.frame(matrix(ncol=(End/INP$Time_slice)*length(FLEETSEGMENTS_names),nrow=(max(n_ages_mal, n_ages_fem) )), row.names=paste("age", c(first_age:(max(n_ages_mal, n_ages_fem)+first_age-1)), sep=""))

SRO$Annual_F_by_year = data.frame(matrix(nrow=End/INP$Time_slice,ncol=1))
SRO$Annual_F_by_year_ls = data.frame(matrix(nrow=End/INP$Time_slice,ncol=1))
SRO$Annual_F_by_gear_by_year = data.frame(matrix(nrow=End/INP$Time_slice,ncol=length(FLEETSEGMENTS_names)))
SRO$Annual_F_by_gear_by_year_ls = data.frame(matrix(nrow=End/INP$Time_slice,ncol=length(FLEETSEGMENTS_names)))

SRO$Annual_M_males =  data.frame(matrix(ncol=End/INP$Time_slice,nrow=n_ages_mal), row.names=c(first_age:(n_ages_mal+first_age-1)) )
SRO$Annual_M_females =  data.frame(matrix(ncol=End/INP$Time_slice,nrow= n_ages_fem) , row.names=c(first_age:(n_ages_fem+first_age-1)) )
SRO$Annual_M =  data.frame(matrix(ncol=End/INP$Time_slice,nrow=(max(n_ages_mal, n_ages_fem)) ), row.names= c(first_age:(max(n_ages_mal, n_ages_fem)+first_age-1)) )

SRO$Annual_M_males[1,] = mean(BAS$MM[indices_M_first_age]) 
SRO$Annual_M_females[1,] = mean(BAS$FM[indices_F_first_age]) 



for (i in loca) {
SRO$Annual_M[1,i] =  mean(na.omit(c(SRO$Annual_M_males[1,i],SRO$Annual_M_females[1,i])))
}













for (a in  (first_age+1):n_ages_mal){ 
SRO$Annual_M_males[rownames(SRO$Annual_M_males) ==  a,] = mean(BAS$MM[which(BAS$indices_MAge$age_class == a)+1])
}

for (a in  (first_age+1):n_ages_fem) {
SRO$Annual_M_females[rownames(SRO$Annual_M_females) ==  a,] = mean(BAS$FM[which(BAS$indices_FAge$age_class == a)+1])
}

for (a in  (first_age+1):max(n_ages_mal, n_ages_fem)) {
SRO$Annual_M[rownames(SRO$Annual_M) ==  a,] =  mean(na.omit(c(SRO$Annual_M_males[rownames(SRO$Annual_M_males) == a,i],SRO$Annual_M_females[rownames(SRO$Annual_M_females) ==  a,i])))
}

    
SRO$Annual_F_males =  data.frame(SRO$Annual_Z_males - SRO$Annual_M_males , row.names= c(first_age:(n_ages_mal+first_age-1)) )
SRO$Annual_F_females = data.frame(SRO$Annual_Z_females - SRO$Annual_M_females , row.names=c(first_age:( n_ages_fem+first_age-1)) )
SRO$Annual_F = data.frame(SRO$Annual_Z - SRO$Annual_M, row.names= c(first_age:(max(n_ages_mal, n_ages_fem)+first_age-1)) )


colnames(SRO$Annual_F_males) =  loca_y
colnames(SRO$Annual_F_females) =  loca_y
colnames(SRO$Annual_F) =  loca_y
#
#rownames(SRO$Annual_F_males) =  seq(trunc(INP$tr/12),(max(INP$MGrowth_tend,INP$FGrowth_tend)-1),1)
#rownames(SRO$Annual_F_females) = seq(trunc(INP$tr/12),(max(INP$MGrowth_tend,INP$FGrowth_tend)-1),1)
#rownames(SRO$Annual_F) =  seq(trunc(INP$tr/12),(max(INP$FGrowth_tend,INP$MGrowth_tend)-1),1)

# DISAGGREGAZIONE PER SEGMENTI
  #for (year in loca){
#        for (gear in 1:length(FLEETSEGMENTS_names))  {
#        SRO$Annual_F_by_gear[,(year-1)*length(FLEETSEGMENTS_names)+gear] = SRO$Annual_F[,year]  * meanWequals(SRO$pj[1:End,gear],End, INP$Time_slice) [year]
#        }
#  }


# calcolo valori annuali
for (i in 1:ncol(SRO$Annual_F)){
    SRO$Annual_F_by_year_ls[i,1]= mean(SRO$Annual_F[,i],na.rm=T)
    SRO$Annual_F_by_year[i,1]=(mean(SRO$Annual_F_males[which(rownames(SRO$Annual_F_males) ==  INP$min_ageM):which(rownames(SRO$Annual_F_males) ==  INP$max_ageM ),i],na.rm=T)  + mean(SRO$Annual_F_females[which(rownames(SRO$            Annual_F_females) ==  INP$min_ageF):which(rownames(SRO$Annual_F_females) ==  INP$max_ageF ),i],na.rm=T)) / 2
    }
    
# DISAGGREGAZIONE PER SEGMENTI dei valori annuali


load_catches_by_age(End)

catch=read.table(CATCHBYAGE_table,sep=";",header=T)
#land=read.table(LANDINGBYAGE_table,sep=";",header=T)
#disc=read.table(DISCARDBYAGE_table,sep=";",header=T)
colnames (catch) [2:(ncol(catch)-2)]= seq(trunc(INP$tr/12),(max(INP$MGrowth_tend,INP$FGrowth_tend)-1),1)  

catch_totF=  array(dim=c((End)/INP$Time_slice, max(n_ages_mal,n_ages_fem) ))  
catch_totM=   array(dim=c((End)/INP$Time_slice,max(n_ages_mal,n_ages_fem) ))  
catchF =  catch[as.character(catch$sex)=="F" ,]
catchM =  catch[as.character(catch$sex)=="M" ,]

for (yea in 1:length(loca_y)){ 
    for (age in (1:max(n_ages_mal,n_ages_fem))){
    catch_totF [yea, age] = sum(catchF[catchF$Year==loca_y[yea],1+age])   
    catch_totM [yea, age] = sum(catchM[catchM$Year==loca_y[yea],1+age])                 
    }
}

for (i in 1:length(FLEETSEGMENTS_names)){
catchF_g =  catch[as.character(catch$sex)=="F" & as.character(catch$Gear)== FLEETSEGMENTS_names[i],]
catchM_g =  catch[as.character(catch$sex)=="M" & as.character(catch$Gear)== FLEETSEGMENTS_names[i],]
for (y in loca){
    for (a in 1 : n_ages_mal  ){
    SRO$Annual_F_males_by_gear  [y,a,i] =   ifelse(as.numeric(catch_totM[y, a])!= 0, SRO$Annual_F_males[a,y]*as.numeric(catchM_g[y, a+1])/ as.numeric(catch_totM[y, a]), 0)
    } 
    for (a in 1 : n_ages_fem  )   {
    SRO$Annual_F_females_by_gear [y,a,i]  =  ifelse(as.numeric(catch_totF[y, a]) != 0, SRO$Annual_F_females[a, y]*as.numeric(catchF_g[y, a+1])/ as.numeric(catch_totF[y, a]) , 0)
    }
}


}

dimnames(SRO$Annual_F_males_by_gear) =  list(loca_y,rownames(SRO$Annual_Z_males),FLEETSEGMENTS_names) 
dimnames(SRO$Annual_F_females_by_gear) =  list(loca_y,rownames(SRO$Annual_Z_females),FLEETSEGMENTS_names) 

for (g in 1:length(FLEETSEGMENTS_names)){
SRO$Annual_F_by_gear_by_year_ls[,g]   =   (rowMeans(data.frame(matrix(SRO$Annual_F_males_by_gear[,,g], nrow=length(loca_y) )) ) +   rowMeans( data.frame(matrix(SRO$Annual_F_females_by_gear[,,g], nrow=length(loca_y)))))/2
SRO$Annual_F_by_gear_by_year[,g]   =   (rowMeans(data.frame(matrix(SRO$Annual_F_males_by_gear[,which(colnames(SRO$Annual_F_males_by_gear) %in%  c(INP$min_ageM:INP$max_ageM)) ,g], nrow=length(loca_y))) ) +   rowMeans(data.frame(matrix(SRO$Annual_F_females_by_gear[,which(colnames(SRO$Annual_F_females_by_gear) %in%  c(INP$min_ageF:INP$max_ageF)),g], nrow=length(loca_y))) ))/2                                                                                                   # c((loca_min_ageM+1):(INP$max_ageM+1))
}    

 
colnames(SRO$Annual_F_by_gear_by_year)= FLEETSEGMENTS_names
colnames(SRO$Annual_F_by_gear_by_year_ls)= FLEETSEGMENTS_names
rownames(SRO$Annual_F_by_gear_by_year)= loca_y
rownames(SRO$Annual_F_by_gear_by_year)= loca_y  



  for (g in 1:length(FLEETSEGMENTS_names)){                                             #sex	Gear

      tow <- data.frame(matrix(0, ncol=max(n_ages_mal, n_ages_fem), nrow=length(loca_y) ))
  tow[, 1:n_ages_mal] <- data.frame(matrix(SRO$Annual_F_males_by_gear[,,g], nrow=length(loca_y) )   )
  tow2 <- data.frame(cbind(loca_y, tow))
  colnames(tow2) <- c("Year/Age", colnames(tow))
  tow2$sex = "M"
  tow2$Gear = FLEETSEGMENTS_names[g]
  
   if (g == 1) { 
  tow3 <- tow2
    } else {   
  tow3 <- rbind(tow3, tow2)  
    }

  
    tow <- data.frame(matrix(0, ncol=max(n_ages_mal, n_ages_fem), nrow=length(loca_y) ))  
  tow <- data.frame(matrix(SRO$Annual_F_females_by_gear[,,g], nrow=length(loca_y) ) )
  tow2 <- data.frame(cbind(loca_y, tow))
  colnames(tow2) <- c("Year/Age", colnames(tow))
  tow2$sex = "F"
  tow2$Gear = FLEETSEGMENTS_names[g]

  tow3 <- rbind(tow3, tow2)  
  
  } 

  colnames(tow3)[2: (ncol(tow)+1)] <- c(first_age:(max(n_ages_mal, n_ages_fem)+first_age-1))

   # write.table(tow2,paste(F_BYGEAR_MALES_table, FLEETSEGMENTS_names[g],".csv",sep=""),sep=";",row.names=F)   
  #  write.table(tow2,paste(F_BYGEAR_FEMALES_table,FLEETSEGMENTS_names[g],".csv",sep=""),sep=";",row.names=F)
 
 write.table(tow3,file=F_BYGEAR_table,sep=";",row.names=F) 


















for (i in 1:ncol(SRO$Annual_Z)){
SRO$Annual_Z_by_year_ls[i,1]= mean(SRO$Annual_Z[,i],na.rm=T)
SRO$Annual_Z_by_year[i,1]=(mean(SRO$Annual_Z_males[which(rownames(SRO$Annual_Z_males) ==  INP$min_ageM):which(rownames(SRO$Annual_Z_males) ==  INP$max_ageM ),i],na.rm=T)+mean(SRO$Annual_Z_females[which(rownames(SRO$Annual_Z_females) ==  INP$min_ageF):which(rownames(SRO$Annual_Z_females) ==  INP$max_ageF ),i],na.rm=T)) / 2
}


 if (showCompTime)  {
 proc_ <- proc.time()
# SIMULATION_EXPLOITED_ptm <- proc.time()
print(paste("Annual_F [time]::::::::::::::::::::::::::::::::", round(as.numeric(proc_[3]-Annual_F_ptm[3]),2), "sec" ), quote=F )   
#print(proc.time() - SIMULATION_EXPLOITED_ptm, quote=F ) 
rm(Annual_F_ptm)
}

}