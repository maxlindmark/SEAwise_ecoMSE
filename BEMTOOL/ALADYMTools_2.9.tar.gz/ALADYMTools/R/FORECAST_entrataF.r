# ALADYM  Age length based dynamic model
# Authors: G. Lembo, I. Bitetto, M.T. Facchini, M.T. Spedicato 2013
# COISPA Tecnologia & Ricerca, Via dei Trulli 18/20 - (Bari), Italy 
# In case of use of the model, the Authors should be cited.
# If you have any comments or suggestions please contact the following e-mail address: facchini@coispa.it
# ALADYM is believed to be reliable. However, we disclaim any implied warranty or representation about its accuracy, 
# completeness or appropriateness for any particular purpose.

.FORECAST_entrataF <- function (locaFore_End) {

 if (IN_BEMTOOL) {   
if (BMT_SCENARIO == BMT_HR_TAC_BESC_FCAP_STRATEGY & !exists("TAC_LEVEL_LOOP") & TAC_ROUND != 2)  {

#print("NON STO FACENDO I LIVELLI QUINDI CONTROLLERO\' LA TAC!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!")
  name_TAC_table <- paste(casestudy_path, "/",harvest_rule_id, "/", casestudy_name, " - TAC table ", harvest_rule_id," CI.csv", sep="")
   CI_TAC_table_inner <- read.csv( name_TAC_table,  sep=";", header=T)   
}
}

 # locaFore_End = forecast
ptm_inner_ <- proc.time()
REACHED <- rep(F, nb_gears)


#if (FALSE) {
#locaFore_End =forecast
#  loca_Fertility <- 1
# loca_min_BAS.MM  <- mean(BAS$MM)
# loca_min_BAS.FM <- mean(BAS$FM)
#}


MC_number_months_age <- GLO$MC_number
FC_number_months_age <- GLO$FC_number
FMC_number_months_age <- max(MC_number_months_age, FC_number_months_age)

loca_discardsM_fore = matrix(nrow = GLO$MC_number,ncol = 0)
loca_discardsF_fore = matrix(nrow = GLO$FC_number,ncol = 0)
dis_vec_sea_survM = matrix(nrow = (GLO$MC_number-1),ncol = nb_gears)
dis_vec_sea_survF = matrix(nrow = (GLO$FC_number-1),ncol = nb_gears)
dis_vec_sea_diedM = matrix(nrow = (GLO$MC_number-1),ncol = nb_gears)
dis_vec_sea_diedF = matrix(nrow = (GLO$FC_number-1),ncol = nb_gears)
esc_vec_survM = matrix(nrow = (GLO$MC_number-1),ncol = nb_gears) 
esc_vec_survF = matrix(nrow = (GLO$FC_number-1),ncol = nb_gears) 

loca_Mcapture_gears = vector(mode="numeric",length = nb_gears)         
loca_Mcapture_gears_lan = vector(mode="numeric",length = nb_gears)
loca_Mcapture_gears_dis = vector(mode="numeric",length = nb_gears)
loca_Mcapture_gears_dis_landed = vector(mode="numeric",length = nb_gears)
loca_Mcapture_gears_dis_sea = vector(mode="numeric",length = nb_gears)
loca_Fcapture_gears = vector(mode="numeric",length = nb_gears)
loca_Fcapture_gears_lan = vector(mode="numeric",length = nb_gears)
loca_Fcapture_gears_dis = vector(mode="numeric",length = nb_gears)
loca_Fcapture_gears_dis_landed = vector(mode="numeric",length = nb_gears)
loca_Fcapture_gears_dis_sea = vector(mode="numeric",length = nb_gears)

loca_temp_cbiomass_gears =  vector(mode="numeric",length = nb_gears)
loca_temp_cbiomass_gears_lan =  vector(mode="numeric",length = nb_gears)
loca_temp_cbiomass_gears_dis =  vector(mode="numeric",length = nb_gears)
loca_temp_cbiomass_gears_dis_landed =  vector(mode="numeric",length = nb_gears)
loca_temp_cbiomass_gears_dis_sea =  vector(mode="numeric",length = nb_gears)

loca_temp_cbiomass_gearsM = vector(mode="numeric",length = nb_gears)
loca_temp_cbiomass_gearsM_lan = vector(mode="numeric",length = nb_gears)
loca_temp_cbiomass_gearsM_dis = vector(mode="numeric",length = nb_gears)
loca_temp_cbiomass_gearsM_dis_landed = vector(mode="numeric",length = nb_gears)
loca_temp_cbiomass_gearsM_dis_sea = vector(mode="numeric",length = nb_gears)

loca_temp_cbiomass_gearsF =  vector(mode="numeric",length = nb_gears)
loca_temp_cbiomass_gearsF_lan =  vector(mode="numeric",length = nb_gears)
loca_temp_cbiomass_gearsF_dis =  vector(mode="numeric",length = nb_gears)
loca_temp_cbiomass_gearsF_dis_landed =  vector(mode="numeric",length = nb_gears)
loca_temp_cbiomass_gearsF_dis_sea =  vector(mode="numeric",length = nb_gears)

loca_temp_age_mean_gears  =  vector(mode="numeric",length = nb_gears)
loca_temp_age_mean_gears_lan  =  vector(mode="numeric",length = nb_gears)
loca_temp_age_mean_gears_dis  =  vector(mode="numeric",length = nb_gears)
loca_temp_age_mean_gears_dis_landed  =  vector(mode="numeric",length = nb_gears)
loca_temp_age_mean_gears_dis_sea  =  vector(mode="numeric",length = nb_gears)

loca_temp_length_mean_gears =  vector(mode="numeric",length = nb_gears)
loca_temp_length_mean_gears_lan =  vector(mode="numeric",length = nb_gears)
loca_temp_length_mean_gears_dis =  vector(mode="numeric",length = nb_gears)
loca_temp_length_mean_gears_dis_landed =  vector(mode="numeric",length = nb_gears)
loca_temp_length_mean_gears_dis_sea =  vector(mode="numeric",length = nb_gears)

loca_temp_total_captured_gears = vector(mode="numeric",length = nb_gears)
loca_temp_total_captured_gears_lan = vector(mode="numeric",length = nb_gears)
loca_temp_total_captured_gears_dis = vector(mode="numeric",length = nb_gears)
loca_temp_total_captured_gears_dis_landed = vector(mode="numeric",length = nb_gears)
loca_temp_total_captured_gears_dis_sea = vector(mode="numeric",length = nb_gears)
# No Fertility
  loca_Fertility                     <- 1
  
# Base value of natural mortality to calculate FMax
  loca_min_BAS.MM                     <- mean(BAS$MM)
  loca_min_BAS.FM                     <- mean(BAS$FM)

  if (INTEGRATED_APPROACH) {
    INP$Ffemales <- updateF.int(INP$Ffemales,(GLO$L_number-forecast+2)) 
 INP$Fmales <- updateF.int(INP$Fmales,GLO$L_number-forecast+2)
 
  if (exists("TAC_LEVEL_LOOP")) {
   # print( "PRIMA:", quote=F)
  #  print(paste("***************************************************  F mortality female WITH LEVEL:", f_TAC), quote=F)
# print(INP$Ffemales[INP$Ffemales$Year == years.forecast[current_year],], quote=F)
# print(paste("" ), quote=FALSE)    
INP$Ffemales[INP$Ffemales$Year == years.forecast[current_year], 3:ncol(INP$Ffemales)] <- INP$Fmales[INP$Ffemales$Year == years[simperiod], 3:ncol(INP$Ffemales)] * f_TAC
 INP$Fmales[INP$Fmales$Year == years.forecast[current_year], 3:ncol(INP$Fmales)] <- INP$Fmales[INP$Fmales$Year == years[simperiod], 3:ncol(INP$Fmales)] * f_TAC
 # print( "DOPO:", quote=F)
 # print(paste("***************************************************  F mortality female WITH LEVEL:", f_TAC), quote=F)
# print(INP$Ffemales[INP$Ffemales$Year == years.forecast[current_year],], quote=F)
# print(paste("" ), quote=FALSE) 
  }  else {
  
 # print(paste("***************************************************  F mortality female in TAC_ROUND:", TAC_ROUND), quote=F)
# print(INP$Ffemales[INP$Ffemales$Year == years.forecast[current_year],], quote=F)
# print(paste("" ), quote=FALSE)     
  
  
  
  }
  
#    if (exists("TAC_ROUND")) {
#    if (TAC_ROUND == 2) {
#     print( "Eseguo 2nd round con F aggiornata:", quote=F)  
#   print( "PRIMA:", quote=F)
#   print(paste("***************************************************  F mortality female 2nd round"), quote=F)
#print(INP$Ffemales[INP$Ffemales$Year == years.forecast[current_year],], quote=F)
#print(paste("" ), quote=FALSE)    
#INP$Ffemales[INP$Ffemales$Year == years.forecast[current_year], 3:ncol(INP$Ffemales)] <- INP$Fmales[INP$Ffemales$Year == years[simperiod], 3:ncol(INP$Ffemales)] * TAC_table$Fcap[TAC_table$species == BMT_SPECIES[ALADYM_spe] & TAC_table$year == years.forecast[current_year]] /  Interactionsyear[[simperiod]][[ALADYM_spe]]@mortalities$F[length(BMT_FLEETSEGMENTS)+1]
# INP$Fmales[INP$Fmales$Year == years.forecast[current_year], 3:ncol(INP$Fmales)] <- INP$Fmales[INP$Fmales$Year == years[simperiod], 3:ncol(INP$Fmales)] * TAC_table$Fcap[TAC_table$species == BMT_SPECIES[ALADYM_spe] & TAC_table$year == years.forecast[current_year]] /  Interactionsyear[[simperiod]][[ALADYM_spe]]@mortalities$F[length(BMT_FLEETSEGMENTS)+1]
# print( "DOPO:", quote=F)
# print(paste("***************************************************  F mortality female 2nd round"), quote=F)
#print(INP$Ffemales[INP$Ffemales$Year == years.forecast[current_year],], quote=F)
#print(paste("" ), quote=FALSE)
#} 
#  } 
  

  } else {
 INP$Ffemales <- updateF(INP$Ffemales,(GLO$L_number-forecast+2))
 INP$Fmales <- updateF(INP$Fmales,GLO$L_number-forecast+2)
   }
 

#  print("INP$Ffemales")
#   print(INP$Ffemales)
  
#-------------------------------------------------------------------------------
	for(loca_irun in ((locaFore_End):GLO$L_number)) {

# inizializzazione: deve ripartire dall'ultimo anno di simulazione   
   BAS$MFPopulation <- SRO$MFPopulation[loca_irun,]
   BAS$FFPopulation <- SRO$FFPopulation[loca_irun,]
    
#                  
    #  creazione matrice prop scarto MASCHI E FEMMINE
       loca_discardsM_fore = matrix(nrow = GLO$MC_number,ncol = 0)
	   loca_discardsF_fore = matrix(nrow = GLO$FC_number,ncol = 0)
	   loca_escapeM_fore = matrix(nrow = GLO$MC_number,ncol = 0)
	   loca_escapeF_fore = matrix(nrow = GLO$FC_number,ncol = 0)
	   for  (g in 1:nb_gears) {        #************************************************************************************ for  GEAR  --- OPTION DISCARD FROM VECTOR  *******************
   if (!is.na(INP$Discard[loca_irun,g])) {
      if(as.character(INP$Discard[loca_irun,g]) =="Y"){
		        if (INP$Type_discard[loca_irun+1,g] == 2) {
#                   if (!exists("f")) { 
          loca_discardsM_fore_temp <-  as.numeric(Discardvector(INP$D_vectorM_fore[INP$D_vectorM_fore$Year==years_forecast[(as.integer((loca_irun-1)/12)+1- length(years))],2+g],BAS$MLength,INP$tr)  )
          loca_discardsF_fore_temp <-  as.numeric(Discardvector(INP$D_vectorF_fore[INP$D_vectorF_fore$Year==years_forecast[(as.integer((loca_irun-1)/12)+1- length(years))],2+g],BAS$FLength,INP$tr) )
#                    } else {
#                       loca_discardsM_fore_temp <-  as.numeric(Discardvector(INP$D_vectorM_fore[D_vectorM_fore$Year==(as.integer((loca_irun-1)/12)+1),2+g],BAS$MLength,INP$tr)      )
#                       loca_discardsF_fore_temp <-  as.numeric(Discardvector(INP$D_vectorF_fore[D_vectorF_fore$Year==(as.integer((loca_irun-1)/12)+1),2+g],BAS$FLength,INP$tr)       )
#                	   }
       	    }   else {
        	     # *****************   
                # males discard REVERSE-OGIVE      
               loca_discardsM_fore_temp <- DISCARDS(INP$Discard[loca_irun+1,g], INP$param6[loca_irun+1,g],INP$param7[loca_irun+1,g],BAS$MLength)
               # females discard  REVERSE-OGIVE  
               loca_discardsF_fore_temp <- DISCARDS(INP$Discard[loca_irun+1,g],INP$param6[loca_irun+1,g],INP$param7[loca_irun+1,g],BAS$FLength)
        
               }
        
            } else if (as.character(INP$Discard[loca_irun,g])=="0"){     # DISCARD equals to 0
                  loca_discardsM_fore_temp <- BAS$MLength
                  loca_discardsM_fore_temp[] <-0 
                  loca_discardsF_fore_temp <- BAS$MLength
                  loca_discardsF_fore_temp[] <-0
            }
      } else {      # DISCARD equals to NA
          loca_discardsM_fore_temp <- BAS$MLength
          loca_discardsM_fore_temp[] <-NA 
          loca_discardsF_fore_temp <- BAS$MLength
          loca_discardsF_fore_temp[] <-NA
      }
      
      
 loca_discardsM_fore = cbind(loca_discardsM_fore,loca_discardsM_fore_temp)
 loca_discardsF_fore = cbind(loca_discardsF_fore,loca_discardsF_fore_temp)       
# males selectivity
# loca_MSelection_sim_temp <- SGEAR(INP$OPT_SG_TYPE[loca_irun+1,g],INP$param1 [loca_irun+1,g], INP$param2[loca_irun+1,g], INP$param3[loca_irun+1,g],INP$param4[loca_irun+1,g], INP$param5[loca_irun+1,g],BAS$MLength)
# loca_MSelection_sim = cbind(loca_MSelection_sim,loca_MSelection_sim_temp)
# # females selectivity
# loca_FSelection_sim_temp <- SGEAR(INP$OPT_SG_TYPE[loca_irun+1,g],INP$param1 [loca_irun+1,g], INP$param2[loca_irun+1,g], INP$param3[loca_irun+1,g],INP$param4[loca_irun+1,g], INP$param5[loca_irun+1,g], BAS$FLength)
# loca_FSelection_sim = cbind(loca_FSelection_sim,loca_FSelection_sim_temp)

 # calculation of vector for escape survivability

# OPTION escape survivability FROM VECTOR  *******************
	if(INP$Esc_Surv_rate_fore[g]=="Y") {                  # ***************************************** Escape SURVIVABILITY = YES
		if (INP$Esc_Surv_rate_type_fore[g] == 3) {
             #if (!exists("f")) { 
                escape_ext_vecM_temp <-  as.numeric(Discardvector(INP$Esc_vectorM_fore[,1+g],BAS$MLength,INP$tr) ) 
                escape_ext_vecF_temp <- as.numeric(Discardvector(INP$Esc_vectorF_fore[,1+g],BAS$FLength,INP$tr) ) 
           # } else {
#               escape_ext_vecM_temp <-  as.numeric(Discardvector(INP$Esc_Surv_rate_vectM_sim[INP$Esc_Surv_rate_vectM_sim$Year==(as.integer((loca_irun-1)/12)+1),2+g],BAS$MLength,INP$tr)      )
#               escape_ext_vecF_temp <-  as.numeric(Discardvector(INP$Esc_Surv_rate_vectF_sim[INP$Esc_Surv_rate_vectF_sim$Year==(as.integer((loca_irun-1)/12)+1),2+g],BAS$FLength,INP$tr)       )
#        	   }
		} else {
		escape_ext_vecM_temp <- BAS$MLength
		escape_ext_vecM_temp[] <-0
		escape_ext_vecF_temp <-BAS$FLength
		escape_ext_vecF_temp[] <-0
		}
 } else {
	  escape_ext_vecM_temp <- BAS$MLength
		escape_ext_vecM_temp[] <-0
		escape_ext_vecF_temp <-BAS$FLength
		escape_ext_vecF_temp[] <-0
 }
   loca_escapeM_fore = cbind(loca_escapeM_fore,escape_ext_vecM_temp)
   loca_escapeF_fore = cbind(loca_escapeF_fore,escape_ext_vecF_temp) 
 }  # ******************************************************************************************************************************** for  GEAR
 
 
colnames(loca_discardsM_fore) = FLEETSEGMENTS_names 
colnames(loca_discardsF_fore) = FLEETSEGMENTS_names 
colnames(loca_escapeM_fore) = FLEETSEGMENTS_names 
colnames(loca_escapeF_fore) = FLEETSEGMENTS_names 
	   loca_M_by_age = matrix(nrow = GLO$MC_number,ncol = 0)
	   loca_F_by_age = matrix(nrow = GLO$FC_number,ncol = 0)
	
	# years_forecast[ ]
	
       for  (g in 1:nb_gears){   
	if (!INTEGRATED_APPROACH) {	   
       loca_M_by_age_temp <-  Fvector(INP$Fmales[INP$Fmales$Year==years_forecast[(as.integer((loca_irun-forecast-1)/12)+1)],2+g],BAS$MLength)          #1:INP$MGrowth_tend,2+g
	   } else {
	    loca_M_by_age_temp <-  Fvector(INP$Fmales[INP$Fmales$Year==years_forecast[current_year],2+g],BAS$MLength)          #1:INP$MGrowth_tend,2+g   
	   }
       loca_M_by_age = cbind(loca_M_by_age,loca_M_by_age_temp)
	   if (!INTEGRATED_APPROACH) {	 
	   loca_F_by_age_temp <-  Fvector(INP$Ffemales[INP$Ffemales$Year==years_forecast[(as.integer((loca_irun-forecast-1)/12)+1)],2+g],BAS$FLength)          #1:INP$MGrowth_tend,2+g
       } else {
	   	   loca_F_by_age_temp <-  Fvector(INP$Ffemales[INP$Ffemales$Year==years_forecast[current_year],2+g],BAS$FLength)          #1:INP$MGrowth_tend,2+g
	   }
	   loca_F_by_age = cbind(loca_F_by_age,loca_F_by_age_temp)
	   }
	   
	   
    colnames(loca_M_by_age) = FLEETSEGMENTS_names   
    colnames(loca_F_by_age) = FLEETSEGMENTS_names 
    loca_MF_matrix = matrix (nrow=length(BAS$MLength), ncol=nb_gears)
    loca_FF_matrix = matrix (nrow=length(BAS$FLength), ncol=nb_gears)
	   
  for (j_F in 1:ncol(loca_MF_matrix)) {
    nrow_months_age_M <- nrow(loca_MF_matrix)
    nrow_months_age_F <- nrow(loca_FF_matrix)
    nrow_months_age <- max(nrow_months_age_M, nrow_months_age_F)
    for (i_FM in 1: nrow_months_age_M) {
			  loca_MF_matrix[i_FM,j_F]  = loca_M_by_age[i_FM,j_F] * INP$Fishing_efforts[loca_irun+1,j_F] * multipliers[loca_irun-locaFore_End+1,j_F] # questa � la F per attrezzo (colonne) e per et�-lunghezza( righe) 
		}
		
		for (i_FM in 1: nrow_months_age_F) {# months of age
			  loca_FF_matrix[i_FM,j_F]  = loca_F_by_age[i_FM,j_F] * INP$Fishing_efforts[loca_irun+1,j_F]* multipliers[loca_irun-locaFore_End+1,j_F]
		}
    }                       
    # MASCHI: Calcolo della F totale e di Z
    loca_MF <- rowSums(loca_MF_matrix)     
    loca_MZ <- BAS$MM + loca_MF
	# FEMMINE: Calcolo della F totale e di Z  
	loca_FF <- rowSums(loca_FF_matrix)
	loca_FZ <- BAS$FM + loca_FF
	
  
	#loca_F_temp_calc = 0
    # MASCHI:CREAZIONE MATRICE CON MORTALIT� NATURALE PER UN ANNO per il calcolo di annual F calculated  
    MFPopulation_temp = BAS$MFPopulation 
	FFPopulation_temp = BAS$FFPopulation
        for (month in (1:12)){
             MFPopulation_temp[MC_number_months_age:2] = MFPopulation_temp[(MC_number_months_age:2) - 1] * exp(-BAS$MM[(MC_number_months_age:2) - 1] * GLO$Delta_t) 
			 FFPopulation_temp[FC_number_months_age:2] = FFPopulation_temp[(FC_number_months_age:2) - 1] * exp(-BAS$FM[(FC_number_months_age:2) - 1] * GLO$Delta_t)   
		}
    # (individui che troverei dopo un anno se agisse solo M)  calcolo di F annuale
	SRO$annual_F_calc_M_num[loca_irun+1] = sum(MFPopulation_temp[(13+INP$min_ageM*12):(INP$max_ageM*12+1-INP$tr)])       # SULL'AGE RANGE
	SRO$annual_F_calc_M_num_ls[loca_irun+1] = sum(MFPopulation_temp[(13:GLO$MC_number)] )  # TUTTO IL LIFESPAN
	# (individui che troverei dopo un anno se agisse solo M)  calcolo di F annuale
	SRO$annual_F_calc_F_num[loca_irun+1] = sum(FFPopulation_temp[(13+INP$min_ageF*12):(INP$max_ageF*12+1-INP$tr)])     # SULL'AGE RANGE
	SRO$annual_F_calc_F_num_ls[loca_irun+1] = sum(FFPopulation_temp[13:GLO$FC_number])       # TUTTO IL LIFESPAN 
	
	
	loca_F_temp_calc_masc = 0
	loca_F_temp_calc_femm = 0
	MFPopulation_temp_dacanc = BAS$MFPopulation   
	FFPopulation_temp_dacanc = BAS$FFPopulation

	# MASCHI e FEMMINE: scorre le colonne (mesi di et�)
	BAS$MFPopulation[(MC_number_months_age:2)] <- BAS$MFPopulation[(MC_number_months_age:2) - 1] * exp(-loca_MZ[(MC_number_months_age:2) - 1] * GLO$Delta_t)
	loca_F_temp_calc_masc <-  sum(MFPopulation_temp_dacanc[(MC_number_months_age:2) - 1] * exp(-BAS$MM[(MC_number_months_age:2) - 1] * GLO$Delta_t)  )

	BAS$FFPopulation[(FC_number_months_age:2)] <- BAS$FFPopulation[(FC_number_months_age:2) - 1] * exp(-loca_FZ[(FC_number_months_age:2) - 1] * GLO$Delta_t)
	loca_F_temp_calc_femm <- sum(FFPopulation_temp_dacanc[(FC_number_months_age:2) - 1] * exp(-BAS$FM[(FC_number_months_age:2) - 1] * GLO$Delta_t) )    # ????? per loca_FZ o per BAS$FM  ??? sono diverse !! [mt]

	loca_F_temp_calc <- loca_F_temp_calc_masc + loca_F_temp_calc_femm
	   	# calcolo dei riproduttori in biomassa e numero secondo l'opzione scelta dall'utente, l'ogiva di maturit� e ritardo	
 if(INP$Fertility_Delay >= loca_irun) {

          		if (SS==1) {
          		loca_SS_Population <- sum(SRO$FFPopulation[1,] * BAS$FMaturity * loca_Fertility * BAS$FWeight)
          		loca_SS_Population_nbF <- sum(SRO$FFPopulation[1,] * BAS$FMaturity * loca_Fertility)
          		loca_SS_Population_nbM <- 0
          		if (INP$S_unit_fore==2){
				      loca_SS_Population <- loca_SS_Population_nbF # numeri solo F
				      }
                  } else if (SS==2){
          		loca_SS_Population <- sum(SRO$FFPopulation[1,] * BAS$FMaturity * loca_Fertility* BAS$FWeight)	 + sum(SRO$MFPopulation[1,] * BAS$MMaturity * loca_Fertility* BAS$MWeight)
              loca_SS_Population_nbF <- sum(SRO$FFPopulation[1,] * BAS$FMaturity * loca_Fertility)
              loca_SS_Population_nbM <- sum(SRO$MFPopulation[1,] * BAS$MMaturity * loca_Fertility)


                  } 
              if (INP$S_unit_fore==2){
				          loca_SS_Population <- loca_SS_Population_nbF + loca_SS_Population_nbM #numeri F+M
              }              

              } else {
                  if (SS==1) {
                  loca_SS_Population <- sum(SRO$FFPopulation[loca_irun - INP$Fertility_Delay,] * BAS$FMaturity * loca_Fertility* BAS$FWeight)
                  loca_SS_Population_nbF <- sum(SRO$FFPopulation[loca_irun - INP$Fertility_Delay,] * BAS$FMaturity * loca_Fertility)
                  loca_SS_Population_nbM <- 0
                  if (INP$S_unit_fore==2){
				          loca_SS_Population <- loca_SS_Population_nbF # numeri solo F
				          }
                  } else if (SS==2){
				          loca_SS_Population <- sum(SRO$FFPopulation[loca_irun - INP$Fertility_Delay,] * BAS$FMaturity * loca_Fertility* BAS$FWeight)	 + sum(SRO$MFPopulation[loca_irun - INP$Fertility_Delay,] * BAS$MMaturity * loca_Fertility* BAS$MWeight)
                  loca_SS_Population_nbF <- sum(SRO$FFPopulation[loca_irun - INP$Fertility_Delay,] * BAS$FMaturity * loca_Fertility)
                  loca_SS_Population_nbM <- sum(SRO$MFPopulation[loca_irun - INP$Fertility_Delay,] * BAS$MMaturity * loca_Fertility)



                  if (INP$S_unit_fore==2){
				          loca_SS_Population <- loca_SS_Population_nbF + loca_SS_Population_nbM #numeri F+M
                  }
                  } 
                            	
				}
                  
    BAS$FFSS_Number[loca_irun+1] <- loca_SS_Population_nbF
    BAS$MFSS_Number[loca_irun+1] <- loca_SS_Population_nbM

	
    #CALCOLO RECLUTE secondo l'opzione inserita dall'utente, secondo il fertility rate e la variabilit� inserita dall'utente  
    if (INP$FRLt_fore != 4) {        
	loca_temp <- RFSS(INP$S_unit_fore,loca_SS_Population, INP$FRLt_fore, INP$FRLa_fore, INP$FRLb_fore, INP$FRLc_fore, INP$Recruits[loca_irun + 1]) * rlnorm(1, 0, 0.3)
	}  else {
  	loca_temp <- RFSS(INP$S_unit_fore,loca_SS_Population, INP$FRLt_fore, INP$FRLa_fore, INP$FRLb_fore, INP$FRLc_fore, INP$Recruits[loca_irun + 1]) 
  }
   INP$Recruits [loca_irun+1] <-   loca_temp  /1000
	 loca_temp <- loca_temp * INP$Fertility_Rate[(loca_irun %% 12) + 1]

  
# RANDOM RECRUITMENT  
#----------------------------  
 #             if (R_type_for==1){
   #            loca_temp <- loca_temp * rlnorm(1, meanlog = R_pam1_for, sdlog = R_pam2_for)
   #           } else if (R_type_for==2) {
  #            loca_temp <- loca_temp * rgamma(1, shape = R_pam1_for, scale = R_pam2_for)
  #            } else if (R_type_for==3) {
  #            loca_temp <- loca_temp * rnorm(1, mean=R_pam1_for, sd=R_pam2_for)
  #            } else if (R_type_for==4) {
   #           loca_temp <- loca_temp * runif(1, min=R_pam1_for, max=R_pam2_for)
   #           } else {
   #           print("Distribution code selected for random recruitment in forecast is not correct!")}
#}
#----------------------------  
             
    # split delle reclute nei due popolazioni sfruttate (MASCHI E FEMMINE)              
	BAS$MFPopulation[1]         <- loca_temp * (1 - INP$Sex_ratio[loca_irun + 1])
    BAS$FFPopulation[1]         <- loca_temp * INP$Sex_ratio[loca_irun + 1]
    BAS$MFR[loca_irun + 1]           <- BAS$MFPopulation[1]
    BAS$FFR[loca_irun + 1]           <- BAS$FFPopulation[1]
                  
    # caricamento dei vettori di output 
	  SRO$MFPopulation[loca_irun + 1,] <- BAS$MFPopulation
	  SRO$FFPopulation[loca_irun + 1,] <- BAS$FFPopulation
    SRO$F_calculated[loca_irun + 1]  <- loca_F_temp_calc
    
#	# inizializzazione variabili locali	
#   loca_temp_cbiomass            <- 0
#   loca_temp_dbiomass            <- 0
#   loca_temp_age_mean            <- 0
#   loca_temp_length_mean         <- 0
#   loca_temp_total_captured      <- 0
#   loca_temp_total_death         <- 0                   

              
# inizializzazione variabili locali	
              loca_temp_cbiomass            <- 0
              loca_temp_dbiomass            <- 0
              loca_temp_age_mean            <- 0
              loca_temp_length_mean         <- 0
              loca_temp_total_captured      <- 0
              loca_temp_total_death         <- 0                   

              
              loca_Mcapture_gears []= 0
              loca_Mcapture_gears_lan []= 0
              loca_Mcapture_gears_dis []= 0
			  loca_Mcapture_gears_dis_landed []= 0
			  loca_Mcapture_gears_dis_sea []= 0
              loca_Fcapture_gears []= 0
              loca_Fcapture_gears_lan []= 0
              loca_Fcapture_gears_dis []= 0
			  loca_Fcapture_gears_dis_landed []= 0
			  loca_Fcapture_gears_dis_sea []= 0
              loca_temp_cbiomass_gears []= 0
              loca_temp_cbiomass_gears_lan []= 0
              loca_temp_cbiomass_gears_dis []= 0
              loca_temp_cbiomass_gearsM []= 0
              loca_temp_cbiomass_gearsM_lan []= 0
              loca_temp_cbiomass_gearsM_dis []= 0
              loca_temp_cbiomass_gearsF []= 0
              loca_temp_cbiomass_gearsF_lan []= 0
              loca_temp_cbiomass_gearsF_dis []= 0

              loca_temp_age_mean_gears  []= 0
              loca_temp_age_mean_gears_lan  []= 0
              loca_temp_age_mean_gears_dis  []= 0
			  loca_temp_age_mean_gears_dis_landed  []= 0
			  loca_temp_age_mean_gears_dis_sea  []= 0
              loca_temp_length_mean_gears []= 0
              loca_temp_length_mean_gears_lan []= 0
              loca_temp_length_mean_gears_dis []= 0
			  loca_temp_length_mean_gears_dis_landed []= 0
			  loca_temp_length_mean_gears_dis_sea []= 0
              loca_temp_total_captured_gears []= 0
              loca_temp_total_captured_gears_lan []= 0
              loca_temp_total_captured_gears_dis []= 0
    # MASCHI: variabili di interesse
	 diff_indM =(SRO$MFPopulation[loca_irun,(1:(GLO$MC_number - 1))] - SRO$MFPopulation[loca_irun + 1,(1:(GLO$MC_number - 1)) + 1])
    #diff_indM [diff_indM<0]=0  
          	
          	
		loca_Mdeath  <- ( BAS$MM[(1:(GLO$MC_number - 1))] / loca_MZ[(1:(GLO$MC_number - 1))]) * diff_indM

        loca_temp_total_death       <- sum(loca_Mdeath)
        loca_temp_dbiomass          <- sum (BAS$MWeight[(1:(GLO$MC_number - 1))] * loca_Mdeath)              

        loca_Mcapture  <- (loca_MF[(1:(GLO$MC_number - 1))] / loca_MZ[(1:(GLO$MC_number - 1))]) * diff_indM
        
		#print("loca_MF")
		#print(loca_MF[(1:(GLO$MC_number - 1))])
		
		SRO$MFCatch[loca_irun + 1,(1:(GLO$MC_number - 1))]    <- loca_Mcapture                #salvataggio catture		
		
        loca_temp_total_captured    <- sum( loca_Mcapture)
        loca_temp_cbiomass          <-sum(BAS$MWeight[(1:(GLO$MC_number - 1))] * loca_Mcapture)
        loca_temp_age_mean          <- sum(BAS$MAge[(1:(GLO$MC_number - 1))]    * loca_Mcapture)
        loca_temp_length_mean       <- sum(BAS$MLength[(1:(GLO$MC_number - 1))] * loca_Mcapture)

              
              loca_temp_total_captured_lan  <- 0
              loca_temp_total_captured_dis  <- 0
              loca_temp_age_mean_lan        <- 0
              loca_temp_length_mean_lan      <- 0
              loca_temp_age_mean_dis        <- 0
              loca_temp_length_mean_dis      <- 0

			             # Calcolo le stesse variabili per attrezzo                             
          		for (g in 1:nb_gears){
         		  ratio_F = loca_MF_matrix[(1:(GLO$MC_number - 1)),g]/loca_MF[(1:(GLO$MC_number - 1))]
         		  ratio_F[!is.finite(ratio_F)] <- 0
         		  catch_vec<-loca_Mcapture*ratio_F 
         		  
          		loca_Mcapture_gears [g] = sum(catch_vec)# ifelse(loca_MF[loca_ipop]==0,0,loca_Mcapture* loca_MF_matrix[loca_ipop,g]/loca_MF[loca_ipop])
              SRO$MFCatch_gears[loca_irun +1, (1:(GLO$MC_number - 1)),g]<-catch_vec # loca_Mcapture_gears [g]                           # salvataggio catture 
          		
              lan_vec <-catch_vec * (1-loca_discardsM_fore[(1:(GLO$MC_number - 1)),g]) 
              loca_Mcapture_gears_lan[g]=  sum(lan_vec) #loca_Mcapture_gears [g] * (1-loca_discardsM_fore[loca_ipop,g])
              SRO$MFLanding_gears[loca_irun +1, (1:(GLO$MC_number - 1)),g] <- lan_vec #(loca_Mcapture*ratio_F * (1-loca_discardsM_fore[(1:(GLO$MC_number - 1)),g]) 
                        	
if(!is.na(INP$Discard[loca_irun,g])) {           	            # ��������������������������������������������� set the DISCARD  (males)

    dis_vec <- catch_vec - lan_vec 

			  if (as.character(INP$Land_obl[loca_irun,g])=="Y") { #IF THERE IS LANDING OBBLIGATION, ALL THE DISCARD IS LANDED AND DIED
			  dis_vec_landed <- dis_vec
			  dis_vec_sea  <- dis_vec
			  dis_vec_sea[]  <- 0
			  dis_vec_sea_survM[,g] <- dis_vec
			  dis_vec_sea_survM[,g] <-   0
			  dis_vec_sea_diedM  <- dis_vec_sea_survM #dis_vec
			  dis_vec_sea_diedF  <- dis_vec_sea_survF # dis_vec
			  dis_vec_sea_diedM  [] <-   0
			  dis_vec_sea_diedF  [] <-   0
			  
			  } else if ((as.character(INP$Land_obl[loca_irun,g])=="N") & (INP$Disc_Surv_rate_fore[g]=="Y")) { # NO LANDING OBBLIGATION AND SURVIVAL RATE <>0, ONE PART OF DISCARD SURVIVES, THE OTHER ONE DIED
			  dis_vec_landed <- dis_vec
			  dis_vec_landed[] <- 0
			  dis_vec_sea <- dis_vec
					 
           if (INP$Disc_Surv_rate_type_fore[g] == 1){ # OPTION OF SURVIVABILITY OF DISCARD NOT DEPENDING ON SIZE (CONSTANT)
					  dis_vec_sea_survM[,g] <- INP$Disc_Surv_rate_constM_fore[g] * INP$Survivability_monthly_vec[loca_irun]* dis_vec 

			#if (loca_irun==2) {
            #print("males_survived:")
            #print (dis_vec_sea_survM)
            #}
					  } else if (INP$Disc_Surv_rate_type_fore[g] == 2){ # OPTION OF SURVIVABILITY OF DISCARD DEPENDING ON SIZE (OGIVE)
					  dis_vec_sea_survM[,g] <- INP$Disc_Surv_rate_vectM_fore[,g] * INP$Survivability_monthly_vec[loca_irun]* dis_vec 
			#if (loca_irun==2) {
            #print("males_survived:")
            #print (dis_vec_sea_survM)
            #}
			}
            dis_vec_sea_diedM [,g]<-dis_vec - dis_vec_sea_survM[,g]


            } else { # discard SURVIVAL RATE NULL


			  dis_vec_landed <- dis_vec
			  dis_vec_landed[] <- 0
			  dis_vec_sea <- dis_vec
			  dis_vec_sea_survM [,g] <- dis_vec[]
			  dis_vec_sea_survM[,g] <-   0
        dis_vec_sea_diedM [,g] <- dis_vec
			  }




			  } else {
        dis_vec <- NA
			  dis_vec_landed <- NA
			  dis_vec_sea <- NA
			  dis_vec_sea_survM[,g] <- NA
        dis_vec_sea_diedM [,g]<- NA

              }

loca_Mcapture_gears_dis[g] = sum(dis_vec)
loca_Mcapture_gears_dis_landed[g] = sum(dis_vec_landed)


loca_Mcapture_gears_dis_sea[g] = sum(dis_vec_sea)
			 
SRO$MFDiscard_gears[loca_irun +1, (1:(GLO$MC_number - 1)),g]<- dis_vec 
SRO$MFDiscard_gears_landed[loca_irun +1, (1:(GLO$MC_number - 1)),g]<- dis_vec_landed 
SRO$MFDiscard_gears_sea[loca_irun +1, (1:(GLO$MC_number - 1)),g]<- dis_vec_sea 
		

 loca_temp_cbiomass_gearsM [g] =  sum(catch_vec* BAS$MWeight[(1:(GLO$MC_number - 1))] ) /1000000 #loca_Mcapture_gears[g]* BAS$MWeight[loca_ipop] /1000000       	



              loca_temp_cbiomass_gearsM_lan [g] = sum(lan_vec* BAS$MWeight[(1:(GLO$MC_number - 1))] )/1000000
          	  loca_temp_cbiomass_gearsM_dis [g] = sum(dis_vec* BAS$MWeight[(1:(GLO$MC_number - 1))] )/1000000
			  loca_temp_cbiomass_gearsM_dis_landed [g] = sum(dis_vec_landed* BAS$MWeight[(1:(GLO$MC_number - 1))] )/1000000
			  loca_temp_cbiomass_gearsM_dis_sea [g] = sum(dis_vec_sea* BAS$MWeight[(1:(GLO$MC_number - 1))] )/1000000

              # catture totali
          		loca_temp_total_captured_gears[g] =  loca_Mcapture_gears [g]
          	  loca_temp_age_mean_gears[g] =  sum(BAS$MAge[(1:(GLO$MC_number - 1))]* catch_vec)
          		loca_temp_length_mean_gears [g] =  sum( BAS$MLength[(1:(GLO$MC_number - 1))]* catch_vec)
        		
if(!is.na(INP$Discard[loca_irun,g])& (INP$Fishing_efforts[loca_irun,g]!=0)){
          			loca_temp_total_captured_gears_lan[g] =  loca_Mcapture_gears_lan  [g]
          			loca_temp_total_captured_gears_dis[g] =  loca_Mcapture_gears_dis [g]
					loca_temp_total_captured_gears_dis_landed[g] =  loca_Mcapture_gears_dis_landed [g]
					loca_temp_total_captured_gears_dis_sea[g] =  loca_Mcapture_gears_dis_sea [g]


					
          			loca_temp_age_mean_gears_lan[g] =  sum(BAS$MAge[(1:(GLO$MC_number - 1))]*lan_vec)
          			loca_temp_age_mean_gears_dis[g] =  sum(BAS$MAge[(1:(GLO$MC_number - 1))]*dis_vec)
					loca_temp_age_mean_gears_dis_landed[g] =  sum(BAS$MAge[(1:(GLO$MC_number - 1))]*dis_vec_landed)
					loca_temp_age_mean_gears_dis_sea[g] =  sum(BAS$MAge[(1:(GLO$MC_number - 1))]*dis_vec_sea)

                    loca_temp_length_mean_gears_lan [g] =  sum(BAS$MLength[(1:(GLO$MC_number - 1))]*lan_vec)
          			loca_temp_length_mean_gears_dis [g] =  sum(BAS$MLength[(1:(GLO$MC_number - 1))]*dis_vec)
					loca_temp_length_mean_gears_dis_landed [g] =  sum(BAS$MLength[(1:(GLO$MC_number - 1))]*dis_vec_landed)
					loca_temp_length_mean_gears_dis_sea [g] =  sum(BAS$MLength[(1:(GLO$MC_number - 1))]*dis_vec_sea)


          	
          		  loca_temp_cbiomass_gears_lan[] =loca_temp_cbiomass_gearsM_lan []
            	 # SRO$MFLanding_gears[loca_irun +1,  (1:(GLO$MC_number - 1)),g]<- lan_vec 
                


                loca_temp_cbiomass_gears_dis[] = loca_temp_cbiomass_gearsM_dis []
				loca_temp_cbiomass_gears_dis_landed[] = loca_temp_cbiomass_gearsM_dis_landed []
				loca_temp_cbiomass_gears_dis_sea[] = loca_temp_cbiomass_gearsM_dis_sea []

            	#SRO$MFDiscard_gears[loca_irun +1, (1:(GLO$MC_number - 1)),g]<- dis_vec  
            		
					loca_temp_total_captured_lan =  sum(loca_temp_total_captured_gears_lan,na.rm=T) 
            		loca_temp_total_captured_dis =  sum(loca_temp_total_captured_gears_dis,na.rm=T) 
					loca_temp_total_captured_dis_landed =  sum(loca_temp_total_captured_gears_dis_landed,na.rm=T)
					loca_temp_total_captured_dis_sea =  sum(loca_temp_total_captured_gears_dis_sea,na.rm=T)

            		
					loca_temp_age_mean_lan =  sum(loca_temp_age_mean_gears_lan,na.rm=T) 
            		loca_temp_length_mean_lan =  sum(loca_temp_length_mean_gears_lan,na.rm=T) 

					loca_temp_age_mean_dis =  sum(loca_temp_age_mean_gears_dis,na.rm=T) 
					loca_temp_age_mean_dis_landed =  sum(loca_temp_age_mean_gears_dis_landed,na.rm=T) 
					loca_temp_age_mean_dis_sea =  sum(loca_temp_age_mean_gears_dis_sea,na.rm=T) 
            		loca_temp_length_mean_dis =  sum(loca_temp_length_mean_gears_dis,na.rm=T)
					loca_temp_length_mean_dis_landed =  sum(loca_temp_length_mean_gears_dis_landed,na.rm=T)
					loca_temp_length_mean_dis_sea =  sum(loca_temp_length_mean_gears_dis_sea,na.rm=T)

            		}


              }  
			  
			   SRO$MFLanding[loca_irun +1, (1:(GLO$MC_number - 1))] <- ifelse(nb_gears!=1,rowSums(SRO$MFLanding_gears[loca_irun +1, (1:(GLO$MC_number - 1)),]),sum(SRO$MFLanding_gears[loca_irun +1, (1:(GLO$MC_number - 1)),],na.rm=T))   #salvataggio catture
			   SRO$MFDiscard[loca_irun +1, (1:(GLO$MC_number - 1))] <- ifelse(nb_gears!=1,rowSums(SRO$MFDiscard_gears[loca_irun +1, (1:(GLO$MC_number - 1)),]),sum( SRO$MFDiscard_gears[loca_irun +1, (1:(GLO$MC_number - 1)),],na.rm=T))  #salvataggio catture
			   SRO$MFDiscard_landed[loca_irun +1, (1:(GLO$MC_number - 1))] <- ifelse(nb_gears!=1,rowSums(data.frame(SRO$MFDiscard_gears_landed[loca_irun +1, (1:(GLO$MC_number - 1)),]),na.rm=T),sum(SRO$MFDiscard_gears_landed[loca_irun +1, (1:(GLO$MC_number - 1)),],na.rm=T)) 
			   SRO$MFDiscard_sea[loca_irun +1, (1:(GLO$MC_number - 1))] <- ifelse(nb_gears!=1,rowSums(data.frame(SRO$MFDiscard_gears_sea[loca_irun +1, (1:(GLO$MC_number - 1)),]),na.rm=T),sum(SRO$MFDiscard_gears_sea[loca_irun +1, (1:(GLO$MC_number - 1)),],na.rm=T)) 

			   loca_temp_cbiomass_gears[] = loca_temp_cbiomass_gearsM []						  
      
         # FEMMINE: variabili di interesse     
          diff_indF =(SRO$FFPopulation[loca_irun,(1:(GLO$FC_number - 1))] - SRO$FFPopulation[loca_irun + 1,(1:(GLO$FC_number - 1)) + 1])
         #diff_indF [diff_indF<0]=0  	     
            loca_Fdeath                 <- (BAS$FM[(1:(GLO$FC_number - 1))] / loca_FZ[(1:(GLO$FC_number - 1))]) * diff_indF
          	loca_temp_total_death       <- loca_temp_total_death+ sum(loca_Fdeath)
          	loca_temp_dbiomass          <- loca_temp_dbiomass+sum(BAS$FWeight[(1:(GLO$FC_number - 1))] * loca_Fdeath)
          	loca_Fcapture               <- (loca_FF[(1:(GLO$FC_number - 1))] / loca_FZ[(1:(GLO$FC_number - 1))]) *diff_indF
			
		#print("loca_FF")
		#print(loca_FF[(1:(GLO$FC_number - 1))])
          	
            SRO$FFCatch[loca_irun + 1,(1:(GLO$FC_number - 1))]    <- loca_Fcapture            #salvataggio catture 
            loca_temp_total_captured    <- loca_temp_total_captured + sum(loca_Fcapture)
          	loca_temp_cbiomass          <- loca_temp_cbiomass + sum(BAS$FWeight[(1:(GLO$FC_number - 1))] * loca_Fcapture)
          	loca_temp_age_mean          <- loca_temp_age_mean+ sum(BAS$FAge[(1:(GLO$FC_number - 1))]    * loca_Fcapture)
          	loca_temp_length_mean       <- loca_temp_length_mean + sum(BAS$FLength[(1:(GLO$FC_number - 1))] * loca_Fcapture)
	              for (g in 1:nb_gears){
              ratio_F = loca_FF_matrix[(1:(GLO$FC_number - 1)),g]/loca_FF[(1:(GLO$FC_number - 1))]
         		  ratio_F[!is.finite(ratio_F)] <- 0
         		  catch_vec <- loca_Fcapture*ratio_F
        		  
       		  	loca_Fcapture_gears [g] = sum(catch_vec)# ifelse(loca_MF[loca_ipop]==0,0,loca_Mcapture* loca_MF_matrix[loca_ipop,g]/loca_MF[loca_ipop])



              SRO$FFCatch_gears[loca_irun +1, (1:(GLO$FC_number - 1)),g]<-catch_vec # loca_Mcapture_gears [g]                           # salvataggio catture 
          		
              lan_vec <-catch_vec * (1-loca_discardsF_fore[(1:(GLO$FC_number - 1)),g]) 
              loca_Fcapture_gears_lan[g]=  sum(lan_vec) #loca_Mcapture_gears [g] * (1-loca_discardsM_fore[loca_ipop,g])
              SRO$FFLanding_gears[loca_irun +1, (1:(GLO$FC_number - 1)),g] <- lan_vec #(loca_Mcapture*ratio_F * (1-loca_discardsM_fore[(1:(GLO$MC_number - 1)),g]) 
if(!is.na(INP$Discard[loca_irun,g])) {       # ��������������������������������������������� set the DISCARD  (females)     	
              dis_vec <- catch_vec - lan_vec 
              
			  if (as.character(INP$Land_obl[loca_irun,g])=="Y") { #IF THERE IS LANDING OBBLIGATION, ALL THE DISCARD IS LANDED AND DIED
			  dis_vec_landed <- dis_vec
			  dis_vec_sea  <- dis_vec
		    dis_vec_sea[]  <- 0
			  dis_vec_sea_survF[,g] <- dis_vec
		    dis_vec_sea_survF[,g] <-   0
        dis_vec_sea_diedF [,g] <- dis_vec_sea_survF [,g]
			  dis_vec_sea_diedF  [] <-   0
			  } else if ((as.character(INP$Land_obl[loca_irun,g])=="N") & (INP$Disc_Surv_rate_fore[g]=="Y")) { # NO LANDING OBBLIGATION AND SURVIVAL RATE <>0, ONE PART OF DISCARD SURVIVES, THE OTHER ONE DIED
			  dis_vec_landed <- dis_vec



			  dis_vec_landed[] <- 0
			  dis_vec_sea <- dis_vec
					 
           if (INP$Disc_Surv_rate_type_fore[g] == 1){ # OPTION OF SURVIVABILITY OF DISCARD NOT DEPENDING ON SIZE (CONSTANT)
					  dis_vec_sea_survF[,g] <- INP$Disc_Surv_rate_constF_fore[g] * INP$Survivability_monthly_vec[loca_irun]* dis_vec 
					  #dis_vec_sea_diedF[,g] <-dis_vec - dis_vec_sea_survF[,g]
			#if (loca_irun==2) {
            #print("females_survived:")
            #print (dis_vec_sea_survF)
            #}
            } else if (INP$Disc_Surv_rate_type_fore[g] == 2){ # OPTION OF SURVIVABILITY OF DISCARD DEPENDING ON SIZE (OGIVE)
					  dis_vec_sea_survF[,g] <- INP$Disc_Surv_rate_vectF_fore[,g] * INP$Survivability_monthly_vec[loca_irun]* dis_vec 

			#if (loca_irun==2) {
            #print("females_survived:")
            #print (dis_vec_sea_survF)
            #}
					  }

            dis_vec_sea_diedF[,g] <-dis_vec - dis_vec_sea_survF[,g]  
              } else { #SURVIVAL RATE NULL
			  dis_vec_landed <- dis_vec
			  dis_vec_landed[] <- 0
			  dis_vec_sea <- dis_vec
			  dis_vec_sea_survF [,g] <- dis_vec[]
			  dis_vec_sea_survF[,g] <-   0
        dis_vec_sea_diedF[,g] <- dis_vec
			  }






			  } else {



        dis_vec[] <- NA
			  dis_vec_landed[] <- NA
			  dis_vec_sea[] <- NA
			  dis_vec_sea_survF[,g] <- NA
        dis_vec_sea_diedF[,g] <- NA



}
             loca_Fcapture_gears_dis[g] = sum(dis_vec)
		     loca_Fcapture_gears_dis_landed[g] = sum(dis_vec_landed)

			 loca_Fcapture_gears_dis_sea[g] = sum(dis_vec_sea)
			 

              SRO$FFDiscard_gears[loca_irun +1, (1:(GLO$FC_number - 1)),g]<- dis_vec 
			  SRO$FFDiscard_gears_landed[loca_irun +1, (1:(GLO$FC_number - 1)),g]<- dis_vec_landed 
			  SRO$FFDiscard_gears_sea[loca_irun +1, (1:(GLO$FC_number - 1)),g]<- dis_vec_sea 


              loca_temp_cbiomass_gearsF [g] =  sum(catch_vec* BAS$FWeight[(1:(GLO$FC_number - 1))] ) /1000000 #loca_Mcapture_gears[g]* BAS$MWeight[loca_ipop] /1000000       	

              loca_temp_cbiomass_gearsF_lan [g] = sum(lan_vec* BAS$FWeight[(1:(GLO$FC_number - 1))] )/1000000


          	  loca_temp_cbiomass_gearsF_dis [g] = sum(dis_vec* BAS$FWeight[(1:(GLO$FC_number - 1))] )/1000000
			  loca_temp_cbiomass_gearsF_dis_landed [g] = sum(dis_vec_landed* BAS$FWeight[(1:(GLO$FC_number - 1))] )/1000000
			  loca_temp_cbiomass_gearsF_dis_sea [g] = sum(dis_vec_sea* BAS$FWeight[(1:(GLO$FC_number - 1))] )/1000000

              # catture totali
          	  loca_temp_total_captured_gears[g] =  loca_temp_total_captured_gears[g] + loca_Fcapture_gears [g]
          	  loca_temp_age_mean_gears[g] =   loca_temp_age_mean_gears[g]+ sum(BAS$FAge[(1:(GLO$FC_number - 1))]* catch_vec)
          	  loca_temp_length_mean_gears [g] =  loca_temp_length_mean_gears [g]  + sum( BAS$FLength[(1:(GLO$FC_number - 1))]* catch_vec)
       
                 
                      if(!is.na(INP$Discard[loca_irun,g])& (INP$Fishing_efforts[loca_irun,g]!=0)){

                      loca_temp_total_captured_gears_lan[g] =  loca_temp_total_captured_gears_lan[g] + loca_Fcapture_gears_lan [g]
                      loca_temp_total_captured_gears_dis[g] =  loca_temp_total_captured_gears_dis[g] + loca_Fcapture_gears_dis [g]
					  loca_temp_total_captured_gears_dis_landed[g] =  loca_temp_total_captured_gears_dis_landed[g] + loca_Fcapture_gears_dis_landed [g]
					  loca_temp_total_captured_gears_dis_sea[g] =  loca_temp_total_captured_gears_dis_sea[g] + loca_Fcapture_gears_dis_sea [g]


                      loca_temp_age_mean_gears_lan[g] =  loca_temp_age_mean_gears_lan[g] + sum(BAS$FAge[(1:(GLO$FC_number - 1))]*lan_vec)
                      loca_temp_age_mean_gears_dis[g] =  loca_temp_age_mean_gears_dis[g] + sum(BAS$FAge[(1:(GLO$FC_number - 1))]*dis_vec)
					  loca_temp_age_mean_gears_dis_landed[g] =  loca_temp_age_mean_gears_dis_landed[g] + sum(BAS$FAge[(1:(GLO$FC_number - 1))]*dis_vec_landed)
					  loca_temp_age_mean_gears_dis_sea[g] =  loca_temp_age_mean_gears_dis_sea[g] + sum(BAS$FAge[(1:(GLO$FC_number - 1))]*dis_vec_sea)


                      loca_temp_length_mean_gears_lan [g] =  loca_temp_length_mean_gears_lan[g] + sum(BAS$FLength[(1:(GLO$FC_number - 1))]*lan_vec)
                      loca_temp_length_mean_gears_dis [g] =  loca_temp_length_mean_gears_dis[g] + sum(BAS$FLength[(1:(GLO$FC_number - 1))]*dis_vec)
					  loca_temp_length_mean_gears_dis_landed [g] =  loca_temp_length_mean_gears_dis_landed[g] + sum(BAS$FLength[(1:(GLO$FC_number - 1))]*dis_vec_landed)
					  loca_temp_length_mean_gears_dis_sea [g] =  loca_temp_length_mean_gears_dis_sea[g] + sum(BAS$FLength[(1:(GLO$FC_number - 1))]*dis_vec_sea)


                      loca_temp_cbiomass_gears_lan[] = loca_temp_cbiomass_gears_lan [] + loca_temp_cbiomass_gearsF_lan []    


                    #  SRO$FFLanding_gears[loca_irun +1,  (1:(GLO$FC_number - 1)),g]<- lan_vec                          #salvataggio catture   
              
              
          	          loca_temp_cbiomass_gears_dis[] = loca_temp_cbiomass_gears_dis [] + loca_temp_cbiomass_gearsF_dis []
					  loca_temp_cbiomass_gears_dis_landed[] = loca_temp_cbiomass_gears_dis_landed [] + loca_temp_cbiomass_gearsF_dis_landed []
					  loca_temp_cbiomass_gears_dis_sea[] = loca_temp_cbiomass_gears_dis_sea [] + loca_temp_cbiomass_gearsF_dis_sea []



                      SRO$FFDiscard_gears[loca_irun +1, (1:(GLO$FC_number - 1)),g]<- dis_vec                           #salvataggio catture     
          		
                      loca_temp_total_captured_lan =  loca_temp_total_captured_lan+sum(loca_temp_total_captured_gears_lan,na.rm=T) #+ loca_temp_total_captured_lan

          		        loca_temp_total_captured_dis =  loca_temp_total_captured_dis+ sum(loca_temp_total_captured_gears_dis,na.rm=T) #+ loca_temp_total_captured_dis
						loca_temp_total_captured_dis_landed =  loca_temp_total_captured_dis_landed+ sum(loca_temp_total_captured_gears_dis_landed,na.rm=T) 
						loca_temp_total_captured_dis_sea =  loca_temp_total_captured_dis_sea+ sum(loca_temp_total_captured_gears_dis_sea,na.rm=T) 

          		        loca_temp_age_mean_lan =  loca_temp_age_mean_lan+ sum(loca_temp_age_mean_gears_lan,na.rm=T) #+ loca_temp_age_mean_lan

          		        loca_temp_length_mean_lan = loca_temp_length_mean_lan+ sum(loca_temp_length_mean_gears_lan,na.rm=T) #+ loca_temp_length_mean_lan

          		        loca_temp_age_mean_dis =  loca_temp_age_mean_dis+sum(loca_temp_age_mean_gears_dis,na.rm=T) #+ loca_temp_age_mean_dis
						loca_temp_age_mean_dis_landed =  loca_temp_age_mean_dis_landed+sum(loca_temp_age_mean_gears_dis_landed,na.rm=T) 
						loca_temp_age_mean_dis_sea =  loca_temp_age_mean_dis_sea+sum(loca_temp_age_mean_gears_dis_sea,na.rm=T) 
          		        loca_temp_length_mean_dis =  loca_temp_length_mean_dis+ sum(loca_temp_length_mean_gears_dis,na.rm=T) #+ loca_temp_length_mean_dis
						loca_temp_length_mean_dis_landed =  loca_temp_length_mean_dis_landed+ sum(loca_temp_length_mean_gears_dis_landed,na.rm=T)
						loca_temp_length_mean_dis_sea =  loca_temp_length_mean_dis_sea+ sum(loca_temp_length_mean_gears_dis_sea,na.rm=T)



                      }
           

           
           }
			   SRO$FFLanding[loca_irun +1, (1:(GLO$FC_number - 1))] <- ifelse(nb_gears!=1,rowSums(SRO$FFLanding_gears[loca_irun +1, (1:(GLO$MC_number - 1)),]),sum(SRO$FFLanding_gears[loca_irun +1, (1:(GLO$MC_number - 1)),],na.rm=T))   #salvataggio catture
			   SRO$FFDiscard[loca_irun +1, (1:(GLO$FC_number - 1))] <- ifelse(nb_gears!=1,rowSums(SRO$FFDiscard_gears[loca_irun +1, (1:(GLO$MC_number - 1)),]),sum( SRO$FFDiscard_gears[loca_irun +1, (1:(GLO$MC_number - 1)),],na.rm=T))  #salvataggio catture
			   SRO$FFDiscard_landed[loca_irun +1, (1:(GLO$FC_number - 1))] <- ifelse(nb_gears!=1,rowSums(data.frame(SRO$FFDiscard_gears_landed[loca_irun +1, (1:(GLO$FC_number - 1)),]),na.rm=T),sum(SRO$MFDiscard_gears_landed[loca_irun +1, (1:(GLO$MC_number - 1)),],na.rm=T)) 
			   SRO$FFDiscard_sea[loca_irun +1, (1:(GLO$FC_number - 1))] <- ifelse(nb_gears!=1,rowSums(data.frame(SRO$FFDiscard_gears_sea[loca_irun +1, (1:(GLO$FC_number - 1)),]),na.rm=T),sum(SRO$MFDiscard_gears_sea[loca_irun +1, (1:(GLO$MC_number - 1)),],na.rm=T)) 

		   
              loca_temp_cbiomass_gears[] = loca_temp_cbiomass_gears [] + loca_temp_cbiomass_gearsF []
   

			  SRO$Death_biomass[loca_irun + 1]       <- loca_temp_dbiomass     / 1E6
			  SRO$Capture_biomass[loca_irun + 1]     <- loca_temp_cbiomass     / 1E6
			  SRO$Capture_age_mean[loca_irun + 1]    <- ifelse(loca_temp_total_captured==0,NA,loca_temp_age_mean    / loca_temp_total_captured)
			  SRO$Capture_length_mean[loca_irun + 1] <- ifelse(loca_temp_total_captured==0,NA,loca_temp_length_mean / loca_temp_total_captured)

 if(any((!is.na(INP$Discard[loca_irun,]))& (INP$Fishing_efforts[loca_irun,]!=0))){           


                  SRO$Discard_biomass[loca_irun + 1]     <-  (sum(SRO$MFDiscard[loca_irun+1,] * BAS$MWeight,na.rm=T) + sum (SRO$FFDiscard[loca_irun+1,] * BAS$FWeight,na.rm=T))/1000000 #sum(loca_temp_cbiomass_gears_dis,na.rm=TRUE)   
                  SRO$Discard_age_mean[loca_irun + 1]    <- ifelse(loca_temp_total_captured_dis==0,NA,loca_temp_age_mean_dis    / loca_temp_total_captured_dis)
                  SRO$Discard_length_mean[loca_irun + 1] <- ifelse(loca_temp_total_captured_dis==0,NA,loca_temp_length_mean_dis / loca_temp_total_captured_dis)
				  
				  SRO$Discard_biomass_landed[loca_irun + 1]     <-  (sum(SRO$MFDiscard_landed[loca_irun+1,] * BAS$MWeight,na.rm=T) + sum (SRO$FFDiscard_landed[loca_irun+1,] * BAS$FWeight,na.rm=T))/1000000 #sum(loca_temp_cbiomass_gears_dis,na.rm=TRUE)   
                  SRO$Discard_age_mean_landed[loca_irun + 1]    <- ifelse(loca_temp_total_captured_dis_landed==0,NA,loca_temp_age_mean_dis_landed    / loca_temp_total_captured_dis_landed)
                  SRO$Discard_length_mean_landed[loca_irun + 1] <- ifelse(loca_temp_total_captured_dis_landed==0,NA,loca_temp_length_mean_dis_landed / loca_temp_total_captured_dis_landed)
				  
				  SRO$Discard_biomass_sea[loca_irun + 1]     <-  (sum(SRO$MFDiscard_sea[loca_irun+1,] * BAS$MWeight,na.rm=T) + sum (SRO$FFDiscard_sea[loca_irun+1,] * BAS$FWeight,na.rm=T))/1000000 #sum(loca_temp_cbiomass_gears_dis,na.rm=TRUE)   
                  SRO$Discard_age_mean_sea[loca_irun + 1]    <- ifelse(loca_temp_total_captured_dis_sea==0,NA,loca_temp_age_mean_dis_sea    / loca_temp_total_captured_dis_sea)
                  SRO$Discard_length_mean_sea[loca_irun + 1] <- ifelse(loca_temp_total_captured_dis_sea==0,NA,loca_temp_length_mean_dis_sea / loca_temp_total_captured_dis_sea)
				  
                  SRO$Landing_biomass[loca_irun + 1]     <- (sum(SRO$MFLanding[loca_irun+1,] * BAS$MWeight,na.rm=T) + sum (SRO$FFLanding[loca_irun+1,] * BAS$FWeight,na.rm=T))/1000000 #sum(loca_temp_cbiomass_gears_lan,na.rm=TRUE)                   		

                  SRO$Landing_age_mean[loca_irun + 1]    <- ifelse(loca_temp_total_captured_lan==0,NA,loca_temp_age_mean_lan    / loca_temp_total_captured_lan)
                  SRO$Landing_length_mean[loca_irun + 1] <- ifelse(loca_temp_total_captured_lan==0,NA,loca_temp_length_mean_lan / loca_temp_total_captured_lan)    

                  } else {
                      SRO$Landing_biomass[loca_irun + 1]     <- SRO$Capture_biomass[loca_irun + 1]
                      SRO$Discard_biomass[loca_irun + 1]     <- ifelse(any(is.na(INP$Discard[loca_irun,])),NA,0)
					  SRO$Discard_biomass_landed[loca_irun + 1]     <- ifelse(any(is.na(INP$Discard[loca_irun,])),NA,0)
					  SRO$Discard_biomass_sea[loca_irun + 1]     <- ifelse(any(is.na(INP$Discard[loca_irun,])),NA,0)
                      
					  SRO$Landing_age_mean[loca_irun + 1]    <- SRO$Capture_age_mean[loca_irun + 1]
                      SRO$Landing_length_mean[loca_irun + 1] <- SRO$Capture_length_mean [loca_irun + 1] 
                      
					  SRO$Discard_age_mean[loca_irun + 1]    <-  NA #ifelse(any(is.na(INP$Discard[loca_irun,])),NA,0)
                      SRO$Discard_length_mean[loca_irun + 1] <- NA #ifelse(any(is.na(INP$Discard[loca_irun,])),NA,0)
					  SRO$Discard_age_mean_landed[loca_irun + 1]    <-  NA #ifelse(any(is.na(INP$Discard[loca_irun,])),NA,0)
                      SRO$Discard_length_mean_landed[loca_irun + 1] <-  NA #ifelse(any(is.na(INP$Discard[loca_irun,])),NA,0)
					  SRO$Discard_age_mean_sea[loca_irun + 1]    <-  NA #ifelse(any(is.na(INP$Discard[loca_irun,])),NA,0)
                      SRO$Discard_length_mean_sea[loca_irun + 1] <-  NA #ifelse(any(is.na(INP$Discard[loca_irun,])),NA,0)



}
 		# output per attrezzo 
          		for (g in 1:nb_gears){
                  SRO$Capture_biomass_gears[loca_irun + 1,g]  = (sum(SRO$MFCatch_gears[loca_irun+1,,g]*BAS$MWeight) + sum(SRO$FFCatch_gears[loca_irun+1,,g]*BAS$FWeight) )/1000000  #loca_temp_cbiomass_gears[g]
                  SRO$Capture_age_mean_gears[loca_irun + 1,g] = ifelse(loca_temp_total_captured_gears[g]==0,NA,loca_temp_age_mean_gears[g] / loca_temp_total_captured_gears[g])
                  SRO$Capture_length_mean_gears[loca_irun + 1,g] = ifelse(loca_temp_total_captured_gears[g]==0,NA,loca_temp_length_mean_gears [g] / loca_temp_total_captured_gears[g])
                
                
                if(!is.na(INP$Discard[loca_irun,g])& (INP$Fishing_efforts[loca_irun,g]!=0)) {      # se il discard non � NA (� 0 o � un numero)

          			SRO$Discard_biomass_gears[loca_irun + 1,g]  = (sum(SRO$MFDiscard_gears[loca_irun+1,,g]*BAS$MWeight,na.rm=T) + sum(SRO$FFDiscard_gears[loca_irun+1,,g]*BAS$FWeight,na.rm=T) )/1000000 # loca_temp_cbiomass_gears_dis[g]
          			SRO$Discard_age_mean_gears[loca_irun + 1,g] = ifelse(loca_temp_total_captured_gears_dis[g]==0,NA,loca_temp_age_mean_gears_dis[g] / loca_temp_total_captured_gears_dis[g])
          			SRO$Discard_length_mean_gears[loca_irun + 1,g] = ifelse(loca_temp_total_captured_gears_dis[g]==0,NA,loca_temp_length_mean_gears_dis[g] / loca_temp_total_captured_gears_dis[g])
          			
					SRO$Discard_biomass_gears_landed[loca_irun + 1,g]  = (sum(SRO$MFDiscard_gears_landed[loca_irun+1,,g]*BAS$MWeight,na.rm=T) + sum(SRO$FFDiscard_gears_landed[loca_irun+1,,g]*BAS$FWeight,na.rm=T) )/1000000 # loca_temp_cbiomass_gears_dis[g]
          			SRO$Discard_age_mean_gears_landed[loca_irun + 1,g] = ifelse(loca_temp_total_captured_gears_dis_landed[g]==0,NA,loca_temp_age_mean_gears_dis_landed[g] / loca_temp_total_captured_gears_dis_landed[g])
          			SRO$Discard_length_mean_gears_landed[loca_irun + 1,g] = ifelse(loca_temp_total_captured_gears_dis_landed[g]==0,NA,loca_temp_length_mean_gears_dis_landed[g] / loca_temp_total_captured_gears_dis_landed[g])
					
					SRO$Discard_biomass_gears_sea[loca_irun + 1,g]  = (sum(SRO$MFDiscard_gears_sea[loca_irun+1,,g]*BAS$MWeight,na.rm=T) + sum(SRO$FFDiscard_gears_sea[loca_irun+1,,g]*BAS$FWeight,na.rm=T) )/1000000 # loca_temp_cbiomass_gears_dis[g]
          			SRO$Discard_age_mean_gears_sea[loca_irun + 1,g] = ifelse(loca_temp_total_captured_gears_dis_sea[g]==0,NA,loca_temp_age_mean_gears_dis_sea[g] / loca_temp_total_captured_gears_dis_sea[g])
          			SRO$Discard_length_mean_gears_sea[loca_irun + 1,g] = ifelse(loca_temp_total_captured_gears_dis_sea[g]==0,NA,loca_temp_length_mean_gears_dis_sea[g] / loca_temp_total_captured_gears_dis_sea[g])
					
					SRO$Landing_biomass_gears[loca_irun + 1,g]  = (sum(SRO$MFLanding_gears[loca_irun+1,,g]*BAS$MWeight,na.rm=T) + sum(SRO$FFLanding_gears[loca_irun+1,,g]*BAS$FWeight,na.rm=T) )/1000000#loca_temp_cbiomass_gears_lan[g]  
          			SRO$Landing_age_mean_gears[loca_irun + 1,g] = ifelse(loca_temp_total_captured_gears_lan[g]==0,NA,loca_temp_age_mean_gears_lan[g] / loca_temp_total_captured_gears_lan[g])
					SRO$Landing_length_mean_gears[loca_irun + 1,g] = ifelse(loca_temp_total_captured_gears_lan[g]==0,NA,loca_temp_length_mean_gears_lan[g] / loca_temp_total_captured_gears_lan[g])


        			  }  else {
                SRO$Discard_biomass_gears[loca_irun + 1,g]  = ifelse(is.na(INP$Discard[loca_irun,g]),NA,0)
          		SRO$Discard_age_mean_gears[loca_irun + 1,g] = NA # ifelse(is.na(INP$Discard[loca_irun,g]),NA,0)
          		SRO$Discard_length_mean_gears[loca_irun + 1,g] = NA #ifelse(is.na(INP$Discard[loca_irun,g]),NA,0)
				
				      SRO$Discard_biomass_gears_landed[loca_irun + 1,g]  = ifelse(is.na(INP$Discard[loca_irun,g]),NA,0)
          		SRO$Discard_age_mean_gears_landed[loca_irun + 1,g] = NA # ifelse(is.na(INP$Discard[loca_irun,g]),NA,0)
          		SRO$Discard_length_mean_gears_landed[loca_irun + 1,g] = NA #ifelse(is.na(INP$Discard[loca_irun,g]),NA,0)
				
				      SRO$Discard_biomass_gears_sea[loca_irun + 1,g]  = ifelse(is.na(INP$Discard[loca_irun,g]),NA,0)
          		SRO$Discard_age_mean_gears_sea[loca_irun + 1,g] = NA #ifelse(is.na(INP$Discard[loca_irun,g]),NA,0)
          		SRO$Discard_length_mean_gears_sea[loca_irun + 1,g] = NA #ifelse(is.na(INP$Discard[loca_irun,g]),NA,0)
				
          		SRO$Landing_biomass_gears[loca_irun + 1,g]  = ifelse(is.na(INP$Discard[loca_irun,g]),SRO$Capture_biomass_gears[loca_irun + 1,g],0) 
          			SRO$Landing_age_mean_gears[loca_irun + 1,g] =  ifelse(is.na(INP$Discard[loca_irun,g]),SRO$Capture_age_mean_gears[loca_irun + 1,g],NA) 
              SRO$Landing_length_mean_gears[loca_irun + 1,g] = ifelse(is.na(INP$Discard[loca_irun,g]),SRO$Capture_length_mean_gears[loca_irun + 1,g],NA)         
                }

}                   

		for (g in 1:nb_gears) {
		    SRO$pj[loca_irun+1,g] =  ifelse(sum(SRO$Capture_biomass_gears[loca_irun+1,])==0,0,SRO$Capture_biomass_gears[loca_irun+1,g]/sum(SRO$Capture_biomass_gears[loca_irun+1,])) # questo pj serve solo per splittare F per attrezzo relativamente a quello specifico mese
    }
esc_vec_survM = matrix(nrow = (GLO$MC_number-1),ncol = nb_gears) 
esc_vec_survF = matrix(nrow = (GLO$FC_number-1),ncol = nb_gears) 
esc_vec_diedM = matrix(nrow = (GLO$MC_number-1),ncol = nb_gears) 
esc_vec_diedM[] = 0
esc_vec_diedF = matrix(nrow = (GLO$FC_number-1),ncol = nb_gears) 
esc_vec_diedF[] = 0
esc_vec_survM[] = 0
esc_vec_survF[] = 0 
			
if (any(INP$Esc_Surv_rate_fore=="Y")){	
Pop_intermediateM = SRO$MFPopulation[loca_irun+1,(1:(GLO$MC_number - 1)) + 1] + SRO$MFCatch[loca_irun +1,1:(GLO$MC_number -1)]
Pop_intermediateM = c(BAS$MFPopulation[1],Pop_intermediateM) 
Pop_intermediateF = SRO$FFPopulation[loca_irun+1,(1:(GLO$FC_number - 1)) + 1] + SRO$FFCatch[loca_irun +1,1:(GLO$FC_number -1)]
Pop_intermediateF = c(BAS$FFPopulation[1],Pop_intermediateF)   
#escapedM = (SRO$MFPopulation[loca_irun + 1,(1:(GLO$MC_number - 1)) + 1]-SRO$MFCatch[loca_irun +1,(1:(GLO$MC_number - 1)) + 1])
#escapedF = (SRO$FFPopulation[loca_irun + 1,(1:(GLO$FC_number - 1)) + 1]-SRO$FFCatch[loca_irun +1,(1:(GLO$FC_number - 1)) + 1])	
esc_vec_survM = matrix(nrow = (GLO$MC_number-1),ncol = nb_gears) 
esc_vec_survF = matrix(nrow = (GLO$FC_number-1),ncol = nb_gears) 
esc_vec_diedM = matrix(nrow = (GLO$MC_number-1),ncol = nb_gears) 
esc_vec_diedM[] = 0
esc_vec_diedF = matrix(nrow = (GLO$FC_number-1),ncol = nb_gears) 
esc_vec_diedF[] = 0
esc_vec_survM[] = 0
esc_vec_survF[] = 0 
#escapedM = BAS$MFPopulation[-1]  
#escapedF = BAS$FFPopulation[-1]   
for (g in 1:nb_gears){          


if (INP$Esc_Surv_rate_fore[g]=="Y") {
    
        if (INP$Esc_Surv_rate_type_fore[g] == 1){ # OPTION OF SURVIVABILITY OF DISCARD NOT DEPENDING ON SIZE (CONSTANT)
					  esc_vec_survM[,g] <- (SRO$pj[loca_irun+1,g] * Pop_intermediateM[2:GLO$MC_number] - SRO$MFCatch_gears[loca_irun +1,(1:(GLO$MC_number - 1)) ,g]) * INP$Esc_Surv_rate_constM_fore[g] #* INP$Survivability_monthly_vec[loca_irun]
					  esc_vec_survF[,g] <- (SRO$pj[loca_irun+1,g] * Pop_intermediateF[2:GLO$FC_number] - SRO$FFCatch_gears[loca_irun +1,(1:(GLO$FC_number - 1)) ,g]) * INP$Esc_Surv_rate_constF_fore[g] #* INP$Survivability_monthly_vec[loca_irun]
					 
					} else if (INP$Esc_Surv_rate_type_fore[g] == 2){ # OPTION OF SURVIVABILITY OF DISCARD DEPENDING ON SIZE (OGIVE)
					  
					  esc_vec_survM[,g] <-(SRO$pj[loca_irun+1,g] * Pop_intermediateM[2:GLO$MC_number] - SRO$MFCatch_gears[loca_irun +1,(1:(GLO$MC_number - 1)) ,g])  * INP$Esc_Surv_rate_vectM_fore[,g]        #* INP$Survivability_monthly_vec[loca_irun]
					  esc_vec_survF[,g] <- (SRO$pj[loca_irun+1,g] * Pop_intermediateF[2:GLO$FC_number] - SRO$FFCatch_gears[loca_irun +1,(1:(GLO$FC_number - 1)) ,g]) * INP$Esc_Surv_rate_vectF_fore[,g]      #* INP$Survivability_monthly_vec[loca_irun] 
					  					  
					  }  else if (INP$Esc_Surv_rate_type_fore[g] == 3){
					  esc_vec_survM[,g] <- (SRO$pj[loca_irun+1,g] * Pop_intermediateM[2:GLO$MC_number] - SRO$MFCatch_gears[loca_irun +1,(1:(GLO$MC_number - 1)) ,g])*  loca_escapeM_fore[(1:(GLO$MC_number - 1)),g]   # * INP$Survivability_monthly_vec[loca_irun] 
					  esc_vec_survF[,g] <- (SRO$pj[loca_irun+1,g] * Pop_intermediateF [2:GLO$FC_number]- SRO$FFCatch_gears[loca_irun +1,(1:(GLO$FC_number - 1)) ,g])  *  loca_escapeF_fore[(1:(GLO$FC_number - 1)),g]  # * INP$Survivability_monthly_vec[loca_irun]
					}
					  
					esc_vec_diedM [,g]<-   (SRO$pj[loca_irun+1,g] * Pop_intermediateM[2:GLO$MC_number] - SRO$MFCatch_gears[loca_irun +1,(1:(GLO$MC_number - 1)) ,g])  - esc_vec_survM [,g] 
					esc_vec_diedF [,g]<-   (SRO$pj[loca_irun+1,g] * Pop_intermediateF[2:GLO$FC_number] - SRO$FFCatch_gears[loca_irun +1,(1:(GLO$FC_number - 1)) ,g])  - esc_vec_survF [,g]  #escapedF * INP$pj[loca_irun+1,g]- esc_vec_survF[,g] 

					#if (loca_irun==8) {
					#print("females DIED:")
					#print (esc_vec_diedF)
					#print (rowSums(esc_vec_diedF))



					 # } 
					} else if (any(SRO$pj[loca_irun+1,] !=0)) {
					  esc_vec_survM[,g] <- SRO$MFPopulation[loca_irun+1,(1:(GLO$MC_number - 1)) + 1]*SRO$pj[loca_irun+1,g] #- SRO$MFCatch_gears[loca_irun +1,(1:(GLO$MC_number - 1)) ,g]# all escaped individuals from that fleet segment survived!
					  esc_vec_diedM[,g] <- 0
					  esc_vec_survF[,g] <- SRO$FFPopulation[loca_irun+1,(1:(GLO$FC_number - 1)) + 1]*SRO$pj[loca_irun+1,g] #- SRO$MFCatch_gears[loca_irun +1,(1:(GLO$MC_number - 1)) ,g]# all escaped individuals from that fleet segment survived!
					  esc_vec_diedF[,g] <- 0
					}
			
}
}	



 # if (loca_irun <4){    print(proc.time() - ptm_inner, quote=F )     }

 
if(any(!is.na(INP$Discard[loca_irun,]))) {  
SurvivedM =  BAS$MFPopulation
dis_vec_sea_survM = rbind(dis_vec_sea_survM,rep(0,nb_gears))
SurvivedM =  rowSums(dis_vec_sea_survM,na.rm=TRUE)
SurvivedF =  BAS$FFPopulation
dis_vec_sea_survF = rbind(dis_vec_sea_survF, rep(0,nb_gears))
SurvivedF =  rowSums(dis_vec_sea_survF,na.rm=TRUE)
}      else {
SurvivedM =  BAS$MFPopulation
SurvivedM[] =  0
SurvivedF =  BAS$FFPopulation
SurvivedF[]=  0

}


weightM = matrix(rep(BAS$MWeight[-1],nb_gears),nrow=nrow(dis_vec_sea_diedM),ncol=nb_gears,byrow=F)
weightF = matrix(rep(BAS$FWeight[-1],nb_gears),nrow=nrow(dis_vec_sea_diedF),ncol=nb_gears,byrow=F)

SRO$Fishery_dependent_death_biomass[loca_irun+1] = sum(rowSums(dis_vec_sea_diedM * weightM,na.rm=T)+ rowSums(esc_vec_diedM*weightM, na.rm=T) , na.rm=T) + sum( rowSums(dis_vec_sea_diedF*weightF,na.rm=T)  + rowSums(esc_vec_diedF*weightF,na.rm=T), na.rm=T)  /1000000

# # THE SURVIVED DISCARD RETURNS IN THE POPULATION at sea
 # if (loca_irun==8){
  #print("males population before")
  #print(BAS$MFPopulation)
  #print("females population before")
  #print(BAS$FFPopulation)
  #}
  
  
  
if(any(INP$Esc_Surv_rate_fore=="Y")){  
esc_vec_survM = rbind(rep(0,nb_gears),esc_vec_survM)
esc_vec_survF = rbind(rep(0,nb_gears),esc_vec_survF)

#if (loca_irun==8){
  #print("not survived males subtracted by the population")
  #print(rowSums(esc_vec_diedM,na.rm=TRUE) )
 # print("not survived females subtracted by the population")
  #print(rowSums(esc_vec_diedF,na.rm=TRUE) )
  #}
BAS$MFPopulation = rowSums(esc_vec_survM,na.rm=TRUE)    # the individuals has to be substracted by the population, because by default they are considerED as all survived
BAS$FFPopulation = rowSums(esc_vec_survF,na.rm=TRUE)
#BAS$MFPopulation[which(BAS$MFPopulation<0)]=0
#BAS$FFPopulation[which(BAS$FFPopulation<0)]=0
if (any(BAS$MFPopulation !=0) ) {
BAS$MFPopulation[1] <- BAS$MFR[loca_irun + 1] 
}
if (any(BAS$FFPopulation !=0) ) {
BAS$FFPopulation[1] <- BAS$FFR[loca_irun + 1]
}
}  

 BAS$MFPopulation = BAS$MFPopulation+SurvivedM
 BAS$FFPopulation = BAS$FFPopulation+SurvivedF 
  
#  if (loca_irun==8){
#  print("males population after")
#  print(BAS$MFPopulation)
#  print("females population after")
#  print(BAS$FFPopulation)
#  }
  
  SRO$MFPopulation[loca_irun+1,] =  BAS$MFPopulation
  SRO$FFPopulation[loca_irun+1,] =  BAS$FFPopulation

dis_vec_sea_survM = matrix(nrow = (GLO$MC_number-1),ncol = nb_gears)
dis_vec_sea_survF = matrix(nrow = (GLO$FC_number-1),ncol = nb_gears)

esc_vec_diedF = matrix(nrow = (GLO$FC_number-1),ncol = nb_gears)
esc_vec_diedM = matrix(nrow = (GLO$MC_number-1),ncol = nb_gears)


 if (IN_BEMTOOL) {   
if (BMT_SCENARIO == BMT_HR_TAC_BESC_FCAP_STRATEGY & !exists("TAC_LEVEL_LOOP") & TAC_ROUND != 2)  {

    associated_fleetsegment <- as.vector(cfg[rownames(cfg)==paste("casestudy.S", ALADYM_spe, ".associatedFleetsegment", sep=""), ])   
associated_fleetsegment <- associated_fleetsegment[!is.na(associated_fleetsegment) & associated_fleetsegment != ""]
associated_fleetsegment_indices <- which(associated_fleetsegment %in% BMT_FLEETSEGMENTS)

for (g in 1:nb_gears){

if (!new_aldForecast@CI_calculation ) {
TAC_quota_gear <- as.numeric(as.character(TAC_table[TAC_table$year == years.forecast[current_year] & TAC_table$species == BMT_SPECIES[ALADYM_spe] , colnames(TAC_table) == paste(BMT_FLEETSEGMENTS[associated_fleetsegment_indices[g]], "_TAC", sep="")] )) 
    } else {
TAC_quota_gear <- as.numeric(as.character(CI_TAC_table_inner[CI_TAC_table_inner$year == years.forecast[current_year] & CI_TAC_table_inner$species == BMT_SPECIES[ALADYM_spe] & CI_TAC_table_inner$run == current_runCI, colnames(CI_TAC_table_inner) == paste(BMT_FLEETSEGMENTS[associated_fleetsegment_indices[g]], "_TAC", sep="")] ))     
    }
    
    if (!is.na(TAC_quota_gear)) {
        if (loca_irun == locaFore_End) { 
 print(paste("TAC calculation for", BMT_FLEETSEGMENTS[associated_fleetsegment_indices[g]], "..."), quote=F)
 print(paste("quota =", round(TAC_quota_gear,2)), quote=F)
}
	if (sum(SRO$Landing_biomass_gears[(locaFore_End+1):(loca_irun + 1),g]) > TAC_quota_gear) {
	
		if (loca_irun != ((simperiod+foreperiod)*12)) {
		  if (TAC_quota_gear == 0 & loca_irun == locaFore_End ) {
              INP$Fishing_efforts[(loca_irun+1),g] = 0
          }
             INP$Fishing_efforts[(loca_irun+2),g] = 0
      }
		
		if (!REACHED[g]) { 
		catch_over_TAC  <- round(sum(SRO$Landing_biomass_gears[(locaFore_End+1):(loca_irun + 1),g]),2)
      print(paste(BMT_FLEETSEGMENTS[associated_fleetsegment_indices[g]], "::::: TAC reached in month", (loca_irun + 1) , "with amount of catch =", catch_over_TAC), quote=F)    
			REACHED[g] <- T
			
 if (!new_aldForecast@CI_calculation ) {

 TAC_table[TAC_table$year == years.forecast[current_year] & TAC_table$species == BMT_SPECIES[ALADYM_spe]  , colnames(TAC_table) == paste(BMT_FLEETSEGMENTS[associated_fleetsegment_indices[g]], "_TAC_reached_in_month", sep="")] <<- ifelse(modulo(loca_irun, 12)==0, MONTHS[12], MONTHS[modulo(loca_irun, 12)])    
    TAC_table[TAC_table$year == years.forecast[current_year] & TAC_table$species == BMT_SPECIES[ALADYM_spe]  , colnames(TAC_table) == paste(BMT_FLEETSEGMENTS[associated_fleetsegment_indices[g]], "_catch_last_month", sep="")] <<- round(SRO$Landing_biomass_gears[(loca_irun + 1),g],2) 
    TAC_table[TAC_table$year == years.forecast[current_year] & TAC_table$species == BMT_SPECIES[ALADYM_spe] , colnames(TAC_table) == paste(BMT_FLEETSEGMENTS[associated_fleetsegment_indices[g]], "_catch_over_TAC", sep="")] <<- catch_over_TAC 

} else {

  CI_TAC_table_inner[CI_TAC_table_inner$year == years.forecast[current_year] & CI_TAC_table_inner$species == BMT_SPECIES[ALADYM_spe] & CI_TAC_table_inner$run == current_runCI, colnames(CI_TAC_table_inner) == paste(BMT_FLEETSEGMENTS[associated_fleetsegment_indices[g]], "_TAC_reached_in_month", sep="")] <- ifelse(modulo(loca_irun, 12)==0, MONTHS[12], MONTHS[modulo(loca_irun, 12)]) 
CI_TAC_table_inner[CI_TAC_table_inner$year == years.forecast[current_year] & CI_TAC_table_inner$species == BMT_SPECIES[ALADYM_spe] & CI_TAC_table_inner$run == current_runCI, colnames(CI_TAC_table_inner) == paste(BMT_FLEETSEGMENTS[associated_fleetsegment_indices[g]], "_catch_over_TAC", sep="")] <- catch_over_TAC
CI_TAC_table_inner[CI_TAC_table_inner$year == years.forecast[current_year] & CI_TAC_table_inner$species == BMT_SPECIES[ALADYM_spe] & CI_TAC_table_inner$run == current_runCI, colnames(CI_TAC_table_inner) == paste(BMT_FLEETSEGMENTS[associated_fleetsegment_indices[g]], "_catch_last_month", sep="")] <- round(SRO$Landing_biomass_gears[(loca_irun + 1),g],2)  

}
	# 	}	
      }
      
	} else {
   if (TAC_quota_gear == 0) {
       if (!new_aldForecast@CI_calculation ) {
         TAC_table[TAC_table$year == years.forecast[current_year] & TAC_table$species == BMT_SPECIES[ALADYM_spe] , colnames(TAC_table) == paste(BMT_FLEETSEGMENTS[associated_fleetsegment_indices[g]], "_TAC_reached_in_month", sep="")] <<- "no fish"
TAC_table[TAC_table$year == years.forecast[current_year] & TAC_table$species == BMT_SPECIES[ALADYM_spe] , colnames(TAC_table) == paste(BMT_FLEETSEGMENTS[associated_fleetsegment_indices[g]], "_catch_last_month", sep="")] <<- 0
    TAC_table[TAC_table$year == years.forecast[current_year] & TAC_table$species == BMT_SPECIES[ALADYM_spe] , colnames(TAC_table) == paste(BMT_FLEETSEGMENTS[associated_fleetsegment_indices[g]], "_catch_over_TAC", sep="")] <<- 0
       } else {
       CI_TAC_table_inner[CI_TAC_table_inner$year == years.forecast[current_year] & CI_TAC_table_inner$species == BMT_SPECIES[ALADYM_spe] & CI_TAC_table_inner$run == current_runCI, colnames(CI_TAC_table_inner) == paste(BMT_FLEETSEGMENTS[associated_fleetsegment_indices[g]], "_TAC_reached_in_month", sep="")] <- "no fish" 
CI_TAC_table_inner[CI_TAC_table_inner$year == years.forecast[current_year] & CI_TAC_table_inner$species == BMT_SPECIES[ALADYM_spe] & CI_TAC_table_inner$run == current_runCI, colnames(CI_TAC_table_inner) == paste(BMT_FLEETSEGMENTS[associated_fleetsegment_indices[g]], "_catch_over_TAC", sep="")] <- 0
CI_TAC_table_inner[CI_TAC_table_inner$year == years.forecast[current_year] & CI_TAC_table_inner$species == BMT_SPECIES[ALADYM_spe] & CI_TAC_table_inner$run == current_runCI, colnames(CI_TAC_table_inner) == paste(BMT_FLEETSEGMENTS[associated_fleetsegment_indices[g]], "_catch_last_month", sep="")] <- 0
       }
   } else {
        if (!new_aldForecast@CI_calculation ) {
         TAC_table[TAC_table$year == years.forecast[current_year] & TAC_table$species == BMT_SPECIES[ALADYM_spe] , colnames(TAC_table) == paste(BMT_FLEETSEGMENTS[associated_fleetsegment_indices[g]], "_TAC_reached_in_month", sep="")] <<- "not reac"
TAC_table[TAC_table$year == years.forecast[current_year] & TAC_table$species == BMT_SPECIES[ALADYM_spe] , colnames(TAC_table) == paste(BMT_FLEETSEGMENTS[associated_fleetsegment_indices[g]], "_catch_last_month", sep="")] <<- -1
    TAC_table[TAC_table$year == years.forecast[current_year] & TAC_table$species == BMT_SPECIES[ALADYM_spe] , colnames(TAC_table) == paste(BMT_FLEETSEGMENTS[associated_fleetsegment_indices[g]], "_catch_over_TAC", sep="")] <<- sum(SRO$Landing_biomass_gears[(locaFore_End+1):(loca_irun + 1),g])
       } else {
       CI_TAC_table_inner[CI_TAC_table_inner$year == years.forecast[current_year] & CI_TAC_table_inner$species == BMT_SPECIES[ALADYM_spe] & CI_TAC_table_inner$run == current_runCI, colnames(CI_TAC_table_inner) == paste(BMT_FLEETSEGMENTS[associated_fleetsegment_indices[g]], "_TAC_reached_in_month", sep="")] <- "not reac" 
CI_TAC_table_inner[CI_TAC_table_inner$year == years.forecast[current_year] & CI_TAC_table_inner$species == BMT_SPECIES[ALADYM_spe] & CI_TAC_table_inner$run == current_runCI, colnames(CI_TAC_table_inner) == paste(BMT_FLEETSEGMENTS[associated_fleetsegment_indices[g]], "_catch_over_TAC", sep="")] <- sum(SRO$Landing_biomass_gears[(locaFore_End+1):(loca_irun + 1),g])
CI_TAC_table_inner[CI_TAC_table_inner$year == years.forecast[current_year] & CI_TAC_table_inner$species == BMT_SPECIES[ALADYM_spe] & CI_TAC_table_inner$run == current_runCI, colnames(CI_TAC_table_inner) == paste(BMT_FLEETSEGMENTS[associated_fleetsegment_indices[g]], "_catch_last_month", sep="")] <- -1
       }
   }
  
  }

 name_TAC_table <- paste(casestudy_path, "/",harvest_rule_id, "/", casestudy_name, " - TAC table ", harvest_rule_id," CI.csv", sep="")
  CI_TAC_table_inner <-  CI_TAC_table_inner[ with(CI_TAC_table_inner , order(species, year, run) ) ,]
    write.table( CI_TAC_table_inner, file=name_TAC_table, sep=";", row.names=F)    
  
}	
       }

} else if (BMT_SCENARIO == BMT_HR_TAC_VARIATION) {
if ( ALADYM_spe == species_TAC) {
associated_fleetsegment <- as.vector(cfg[rownames(cfg)==paste("casestudy.S", ALADYM_spe, ".associatedFleetsegment", sep=""), ])   
associated_fleetsegment <- associated_fleetsegment[!is.na(associated_fleetsegment) & associated_fleetsegment != ""]
associated_fleetsegment_indices <- which(associated_fleetsegment %in% BMT_FLEETSEGMENTS)

for (g in 1:nb_gears){
percentage <- as.numeric(as.character(cfg[rownames(cfg)==paste("casestudy.HR", BMT_SCENARIO, ".F", associated_fleetsegment_indices[g], sep=""), 1]))   
TAC_quota_gear <- BMT_TAC * percentage /100  
 if (loca_irun == locaFore_End) { 
 print(paste("TAC calculation for", BMT_FLEETSEGMENTS[associated_fleetsegment_indices[g]], "..."), quote=F)
 print(paste("quota (", percentage, "%) :", round(TAC_quota_gear,2)), quote=F)
}
	if (sum(SRO$Landing_biomass_gears[(locaFore_End+1):(loca_irun + 1),g]) > TAC_quota_gear) {
			INP$Fishing_efforts[(loca_irun+2),g] = 0
			if (!REACHED[g]) { 
      print(paste(BMT_FLEETSEGMENTS[associated_fleetsegment_indices[g]], "::::: TAC reached in month", (loca_irun + 1) , "with amount of catch =", round(sum(SRO$Landing_biomass_gears[(locaFore_End+1):(loca_irun + 1),g]),2)), quote=F)  
      option_TAC <- as.numeric( as.character( cfg[rownames(cfg) == "casestudy.HR6",1] ) )
      to_add <- data.frame(cbind(BMT_SPECIES[species_TAC], cbind(option_TAC, cbind(years.forecast[TIME_TO_CHANGE_WITH_THE_CURRENT_YEAR-simperiod], cbind(BMT_FLEETSEGMENTS[associated_fleetsegment_indices[g]], cbind(TAC_quota_gear, cbind(ifelse(modulo(loca_irun, 12)==0, MONTHS[12], MONTHS[modulo(loca_irun, 12)]), cbind( round(sum(SRO$Landing_biomass_gears[(locaFore_End+1):(loca_irun + 1),g]),2), "tons") ) ))  ) )) ) 
      colnames(to_add) <-  c( "Stock", "Option_TAC", "Year", "Fleet_segment", "Quota", "Month", "Yield", "Unit")
      TAC_results <<- rbind(TAC_results, to_add)
			REACHED[g] <- T
      }
      
	}
}	


}
} 


}







} # ciclo for months 

#if (ALADYM_spe == 1 & current_year == foreperiod) {
##print(paste("FFCatch out from FORECAST_entrataF at run", i, ":") )
##print(SRO$FFCatch[(forecast+1):(GLO$L_number+1),(1:(GLO$MC_number - 1))])
#write.table(SRO$FFCatch, file=paste(getwd(), "/logs/FFCatch run",i, ".csv" ,sep=""), sep=";")
#write.table(SRO$FFPopulation, file=paste(getwd(), "/logs/FFPopulation run",i, ".csv" ,sep=""), sep=";")
#
#}

  x_y <- data.frame(which(is.na(INP$Discard[c(1:(GLO$L_number+1)),]), arr.ind = T))
     if (ncol(x_y)!=1){
     for (g in 1:nb_gears){ 
     
     #x_y[x_y[,2] ==g,1] 
		 SRO$FFLanding_gears [ x_y[x_y[,2] ==g,1] , (1:(GLO$FC_number - 1)),g ]  =  SRO$FFCatch_gears [ x_y[x_y[,2] ==g,1] , (1:(GLO$FC_number -1 )),g ] 
		 SRO$MFLanding_gears  [ x_y[x_y[,2] ==g,1] , (1:(GLO$MC_number -1)),g ]  =  SRO$MFCatch_gears [ x_y[x_y[,2] ==g,1] , (1:(GLO$MC_number -1)),g ] 
 
		}
		} else {
    SRO$FFLanding_gears [ x_y[,1] , (1:(GLO$FC_number - 1)),1 ]  =  SRO$FFCatch_gears [x_y[,1] , (1:(GLO$FC_number - 1)),1 ] 
	  SRO$MFLanding_gears  [ x_y[,1], (1:(GLO$MC_number -1)),1 ]  =  SRO$MFCatch_gears [  x_y[,1], (1:(GLO$MC_number -1)),1 ] 

    }

# print(round( (proc.time() - ptm_inner_), 2), quote=F )  



if (IN_BEMTOOL ) {
if ( BMT_SCENARIO == BMT_HR_TAC_VARIATION ) {
if (ALADYM_spe == species_TAC) {
associated_fleetsegment <- as.vector(cfg[rownames(cfg)==paste("casestudy.S", ALADYM_spe, ".associatedFleetsegment", sep=""), ])   
associated_fleetsegment <- associated_fleetsegment[!is.na(associated_fleetsegment) & associated_fleetsegment != ""]
associated_fleetsegment_indices <- which(associated_fleetsegment %in% BMT_FLEETSEGMENTS)

for (g in 1:nb_gears){
percentage <- as.numeric(as.character(cfg[rownames(cfg)==paste("casestudy.HR", BMT_SCENARIO, ".F", associated_fleetsegment_indices[g], sep=""), 1]))   
TAC_quota_gear <- BMT_TAC * percentage /100  
 if (loca_irun == locaFore_End) { 
 print(paste("TAC calculation for", BMT_FLEETSEGMENTS[associated_fleetsegment_indices[g]], "..."), quote=F)
 print(paste("quota (", percentage, "%) :", round(TAC_quota_gear,2)), quote=F)
}
	if (sum(SRO$Landing_biomass_gears[(locaFore_End+1):(loca_irun + 1),g]) > TAC_quota_gear) {
			INP$Fishing_efforts[(loca_irun+2),g] = 0
			if (!REACHED[g]) { 
      print(paste(BMT_FLEETSEGMENTS[associated_fleetsegment_indices[g]], "::::: TAC reached in month", (loca_irun + 1) , "with amount of catch =", round(sum(SRO$Landing_biomass_gears[(locaFore_End+1):(loca_irun + 1),g]),2)), quote=F)  
      option_TAC <- as.numeric( as.character( cfg[rownames(cfg) == "casestudy.HR6",1] ) )
      to_add <- data.frame(cbind(BMT_SPECIES[species_TAC], cbind(option_TAC, cbind(years.forecast[TIME_TO_CHANGE_WITH_THE_CURRENT_YEAR-simperiod], cbind(BMT_FLEETSEGMENTS[associated_fleetsegment_indices[g]], cbind(TAC_quota_gear, cbind(ifelse(modulo(loca_irun, 12)==0, MONTHS[12], MONTHS[modulo(loca_irun, 12)]), cbind( round(sum(SRO$Landing_biomass_gears[(locaFore_End+1):(loca_irun + 1),g]),2), "tons") ) ))  ) )) ) 
      colnames(to_add) <-  c( "Stock", "Option_TAC", "Year", "Fleet_segment", "Quota", "Month", "Yield", "Unit")
      TAC_results <<- rbind(TAC_results, to_add)
			REACHED[g] <- T
      }
      
	}
}	
}  
}
}




			 
}