# BEMTOOL - Bio-Economic Model TOOLs - version 2.0
# Authors: G. Lembo, I. Bitetto, M.T. Facchini, M.T. Spedicato 2014
# COISPA Tecnologia & Ricerca, Via dei Trulli 18/20 - (Bari), Italy 
# In case of use of the model, the Authors should be cited.
# If you have any comments or suggestions please contact the following e-mail address: facchini@coispa.it
# BEMTOOL is believed to be reliable. However, we disclaim any implied warranty or representation about its accuracy, 
# completeness or appropriateness for any particular purpose.




.calibration<- function(theta)
{
set.seed(11235) 
#print(theta)
#print(paste("dentro Recruitsnorm:", Recruitsnorm), quote=F)
#print(paste("dentro theta:", theta), quote=F)
#Scale to fit with the required program scale
Offspringcalc<-(Recruitsnorm*theta)#*1000

#Repeat it for the require months 
Recruitscalc<-c(Offspringcalc[1],rep(Offspringcalc,each=12))           

#Name the vector of interest in the Full.r model run

INP$Recruits<-Recruitscalc


#In line 270 of full.r we have INP$Recruits[1], 337 same, 502 all, SRO$Capture_biomass and SRO$Biological_production  seem to be the key things we want.#YOU COULD PROBABLY DELETE THESE LINES SINCE IT WAS JUST USED FOR TESTING

#Run the simulation given the new offspring vector

GLO$Nrun <- 100
#source("src/full.r")
#print("RunModel for this iteration",quote=F)
RunModel(1,(forecast-1))

#Take out the vector of interest and calculate the mean of the vector for each of the years
SRO$Capture_biomass1<-SRO$Capture_biomass[-1]
Totyield1<-array(0,length(TrueYield))
for (i in seq(1:length(TrueYield)))
{
	Totyield1[i]<-sum(SRO$Capture_biomass1[1:12])/12
	SRO$Capture_biomass1<-SRO$Capture_biomass1[-(1:12)]	
}

#Objective function-scale the values so that they match and such that the percentage viewed difference is more manageable
YIELD<<-Totyield1
#print(sum(((TrueYield/100000)-(Totyield1/10000))^2))
sum(((TrueYield/100000)-(Totyield1/10000))^2)
}
